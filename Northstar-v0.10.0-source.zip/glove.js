// Data Glove (I.W.M.D.) interface layer: icon + startup sequence. Pure cosmetics, no network, no storage.
(() => {
  ICONS.eye = '<path d="M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/>';
  const b = h('div', { id: 'boot' }, h('div', { class: 'ring' }), h('div', { class: 'bt' }, h('b', {}, 'I.W.M.D.'), h('small', {}, 'Wrist link paired')), h('div', { class: 'scan' }));
  document.body.append(b); setTimeout(() => b.remove(), 1900);
})();
