(() => {
const $ = (s) => document.querySelector(s);
const hud = h('div', { id: 'hud' }); $('#main').append(hud);
const cell = (label, val, cls = '') => h('span', { class: 'hc ' + cls }, h('i', {}, label), h('b', {}, val));
async function paint() {
  let p = {}; try { p = await ns.privacy.get(); } catch { /* keep blanks */ }
  const armed = p.https && p.block; hud.innerHTML = '';
  hud.append(h('span', { class: 'hc tag' }, h('b', {}, 'I.W.M.D.')), cell('Privacy', armed ? 'Armed' : 'Partial', armed ? 'ok' : 'warn'), cell('Blocked', String((p.blocked || 0) + (p.popups || 0))), cell('Fuzzed', p.stealth ? String(p.fp || 0) : 'Off', p.stealth ? '' : 'warn'), cell('HTTPS', p.https ? 'Forced' : 'Off', p.https ? '' : 'warn'),
    cell('Vault', p.encrypted ? 'Encrypted' : 'Open', p.encrypted ? 'ok' : 'warn'), cell('Tabs', String(NS.tabs().length)), h('span', { class: 'hc grow' }), cell('Local', new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })));
}
paint(); setInterval(paint, 2500);
NS.cmds.popup = (url) => {   // blocked pop-up: ask before opening
  let host = url; try { host = new URL(url).hostname; } catch { /* keep raw */ }
  const t = h('div', { class: 'toast' }, h('span', {}, 'Pop-up held: ' + host), h('button', { class: 'ghost', onclick: () => { NS.newTab(url); t.remove(); } }, 'Open'), h('button', { class: 'ghost', onclick: () => t.remove() }, 'Dismiss'));
  document.body.append(t); setTimeout(() => t.remove(), 9000);
};
})();
