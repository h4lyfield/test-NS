// Copilot: type what you want, it drives the browser. Tools run here; the model call happens in the main process.
(() => {
  const $ = (s) => document.querySelector(s);
  ICONS.spark = '<path d="M12 3l1.8 5.2L19 10l-5.2 1.8L12 17l-1.8-5.2L5 10l5.2-1.8zM19 16l.8 2.2L22 19l-2.2.8L19 22l-.8-2.2L16 19l2.2-.8z"/>';
  const log = h('div', { id: 'cplog' }), inp = h('input', { id: 'cpin', placeholder: 'Tell Northstar what to do…', spellcheck: 'false' });
  const foot = h('div', { class: 'cpfoot' }, h('button', { class: 'ghost', onclick: () => showMods() }, 'Mods'), h('button', { class: 'ghost', onclick: () => showBridges() }, 'Bridges'), h('button', { class: 'ghost', onclick: () => setKey() }, 'API key'), h('button', { class: 'ghost', onclick: () => { hist = []; log.innerHTML = ''; hello(); } }, 'New chat'),
    h('small', {}, 'NOT local: your commands go to Anthropic with your own key.'));
  const cp = h('div', { id: 'cp', class: 'pop hide' }, h('h3', {}, 'Copilot // link'), log, h('div', { class: 'cprow' }, inp), foot);
  document.body.append(cp); cp.onclick = (e) => e.stopPropagation();
  const bAi = h('button', { id: 'bAi', class: 'rb ico', title: 'Copilot (⌘K)', html: ic('spark'), onclick: (e) => { e.stopPropagation(); toggle(); } });
  $('#rail').insertBefore(bAi, $('#bMusic'));
  let hist = [], busy = false;
  const say = (cls, text) => { const m = h('div', { class: 'cm ' + cls }, text); log.append(m); log.scrollTop = 1e9; return m; };
  const hello = () => say('sys', 'Say it like you would to me: "open youtube lofi", "add Reddit to the rail", "turn the accent orange and hide the bookmarks bar".');
  function toggle(force) {
    const open = force ?? cp.classList.contains('hide'); cp.classList.toggle('hide', !open);
    if (open) { if (!log.children.length) hello(); inp.focus(); ns.ai.hasKey().then((k) => { if (!k && !log.querySelector('.nokey')) say('sys nokey', 'No API key yet. Press "API key" below. You need your own key from console.anthropic.com (separate from a Claude chat subscription, billed per use).'); }); }
  }
  document.addEventListener('click', () => cp.classList.add('hide')); addEventListener('keydown', (e) => { if (e.key === 'Escape') cp.classList.add('hide'); });
  NS.cmds.copilot = () => toggle();
  NS.cmds.note = (m) => { const t = h('div', { class: 'toast' }, h('span', {}, m), h('button', { class: 'ghost', onclick: () => t.remove() }, 'OK')); document.body.append(t); setTimeout(() => t.remove(), 12000); };
  async function setKey() {
    const r = await NS.ask('Anthropic API key (sk-ant-…). Stored encrypted on this Mac. Your Copilot commands are sent to Anthropic. Leave empty to remove the saved key.', ['sk-ant-...']);
    if (!r) return; if (!r[0]) { await ns.ai.clearKey(); return say('sys', 'Key removed.'); }
    say('sys', (await ns.ai.setKey(r[0])) ? 'Key saved.' : 'That does not look like an Anthropic key.');
  }
  // Ask the owner before anything risky. Denied = the model is told no.
  const confirm = (title, body) => new Promise((res) => {
    const c = h('div', { class: 'cm card' }, h('b', {}, title), body || '', h('div', { class: 'row' }, h('button', { class: 'ghost', onclick: () => { c.querySelector('.row').remove(); res(false); } }, 'Deny'), h('button', { class: 'cta', onclick: () => { c.querySelector('.row').remove(); res(true); } }, 'Approve')));
    log.append(c); log.scrollTop = 1e9;
  });
  const okUrl = (u) => { const n = NS.norm(String(u || '')); return /^https?:\/\//i.test(n) ? n : null; };
  const SET = ['https', 'block', 'cosmetic', 'ytads', 'stealth', 'strip', 'popups', 'suggest'];
  const tabAt = (i) => (Number.isInteger(i) ? NS.tabs()[i] : NS.cur());
  const T = {
    open_tab: async (a) => { if (!a.url) { NS.newTab('', !!a.private); return 'Opened a blank tab.'; } const u = okUrl(a.url); if (!u) return 'error: not a web address'; NS.newTab(u, !!a.private); return 'Opened ' + u; },
    navigate: async (a) => { const u = okUrl(a.text); if (!u) return 'error: not a web address'; NS.go(a.text); return 'Went to ' + u; },
    close_tab: async (a) => { const t = tabAt(a.index); if (!t) return 'error: no such tab'; NS.close(t); return 'Closed.'; },
    switch_tab: async (a) => { const t = tabAt(a.index); if (!t) return 'error: no such tab'; NS.select(t); return 'Switched.'; },
    list_tabs: async () => NS.tabs().map((t, i) => (t.priv ? i + ': [private tab]' : `${i}: ${(t.title || '').slice(0, 80)} | ${(t.url || '').slice(0, 100)}${t === NS.cur() ? ' (current)' : ''}`)).join('\n') || 'no tabs',
    list_rail: async () => NS.sites().map((s, i) => `${i}: ${s.name} ${s.url}`).join('\n') || 'empty',
    add_rail_site: async (a) => { const u = okUrl(a.url); if (!u || !a.name) return 'error: need a name and a web address'; NS.addSite(String(a.name).slice(0, 30), u); return 'Added.'; },
    remove_rail_site: async (a) => { const s = NS.sites()[a.index]; if (!s) return 'error: no such slot'; if (!(await confirm('Remove "' + s.name + '" from the rail?'))) return 'The owner declined.'; NS.removeSite(a.index); return 'Removed.'; },
    set_theme: async (a) => { if (!NS.themes.includes(a.name)) return 'error: unknown theme'; NS.setTheme(a.name); return 'Theme set.'; },
    set_privacy: async (a) => {
      if (!SET.includes(a.setting)) return 'error: unknown setting';
      if ((!a.enabled || a.setting === 'suggest') && !(await confirm(`${a.enabled ? 'Turn ON' : 'Turn OFF'} "${a.setting}"?`, a.setting === 'suggest' ? 'Search suggestions send what you type to DuckDuckGo.' : 'This weakens your protections.'))) return 'The owner declined.';
      await ns.privacy.set(a.setting, !!a.enabled); return 'Done.';
    },
    get_status: async () => { const p = await ns.privacy.get(); const { https, block, cosmetic, ytads, stealth, strip, popups, suggest, blocked, fp } = p; return JSON.stringify({ https, block, cosmetic, ytads, stealth, strip, popups, suggest, blocked, fp }); },
    set_window_opacity: async (a) => 'Opacity ' + (await ns.setOpacity(a.value)),
    browser_command: async (a) => {
      const n = a.name;
      if (['bookmark', 'bmbar', 'downloads', 'find', 'split', 'vtabs'].includes(n) && NS.cmds[n]) NS.cmds[n]();
      else if (n === 'reload' && NS.cur()) NS.cur().wv.reload();
      else if (n.startsWith('zoom-') && NS.cmds.zoom) NS.cmds.zoom({ in: 1, out: -1, reset: 0 }[n.slice(5)]);
      else if (n.startsWith('music-') && NS.musicCmd) NS.musicCmd(n); else return 'error: not available';
      return 'Done.';
    },
    apply_mod: async (a) => {
      const css = typeof a.css === 'string' ? a.css : '', js = typeof a.js === 'string' ? a.js : '';
      if (!css && !js) return 'error: a mod needs css or js';
      const body = h('div', {}, h('small', {}, a.description || ''), css ? h('pre', {}, css) : '', js ? h('div', {}, h('small', { class: 'warnt' }, 'This JavaScript runs with full access to Northstar\'s interface. Only approve code you understand.'), h('pre', {}, js)) : '');
      if (!(await confirm('Save mod "' + String(a.name).slice(0, 60) + '"?', body))) return 'The owner declined.';
      const id = await ns.mods.save({ name: a.name, description: a.description, css, js }); return id ? 'Saved and applied as ' + id : 'error: mod rejected (too large or empty)';
    },
    bridge_list: async () => { const l = await ns.bridges.list(); return ['adom: Adom Bridge (desktop automation on this Mac)', ...l.map((b) => `${b.id}: ${b.name} ${b.baseUrl}`)].join('\n'); },
    bridge_adom: async (a) => {
      const READ = ['commands', 'desktop_list_windows', 'desktop_list_monitors', 'desktop_permission_status', 'bridge_list', 'targets', 'desktop_mesh_status'];
      const RISKY = /^(shell_execute|run_script|launch_process|write_file|delete_file|process_kill|bridge_install|desktop_click|desktop_type|desktop_press_key|desktop_ui_click|desktop_ui_set|desktop_mouse_click)$/;
      if (!READ.includes(a.command)) {
        const body = h('div', {}, h('small', {}, a.reason || ''), RISKY.test(a.command) ? h('small', { class: 'warnt' }, 'This can run code, change files or control your Mac.') : '', h('pre', {}, JSON.stringify({ app: a.app || 'desktop', command: a.command, args: a.args || {} }, null, 1)));
        if (!(await confirm('Adom Bridge: ' + a.command + '?', body))) return 'The owner declined.';
      }
      return ns.bridges.adom(a.command, a.args, a.app);
    },
    bridge_http: async (a) => {
      const m = a.method || 'GET';
      if (m !== 'GET' && !(await confirm(`${m} ${a.path} on bridge ${a.bridge}?`, h('div', {}, h('small', {}, a.reason || ''), h('pre', {}, String(a.body || '(no body)')))))) return 'The owner declined.';
      return ns.bridges.http(a.bridge, m, a.path, a.body);
    },
    list_mods: async () => (await ns.mods.list()).map((m) => `${m.id}: ${m.name} (${m.on ? 'on' : 'off'}) ${m.description}`).join('\n') || 'none',
    remove_mod: async (a) => { if (!(await confirm('Delete mod ' + a.id + '?'))) return 'The owner declined.'; return (await ns.mods.remove(a.id)) ? 'Deleted (JS parts stay active until restart).' : 'error: no such mod'; },
  };
  // Calls from Codex / local tools through the Northstar local API. Only tools that need no approval card are allowed in.
  const INBOUND = ['open_tab', 'navigate', 'list_tabs', 'switch_tab', 'close_tab', 'list_rail', 'add_rail_site', 'set_theme', 'get_status', 'browser_command', 'set_window_opacity'];
  NS.cmds.api = async ({ id, name, input }) => { let out; try { out = INBOUND.includes(name) && T[name] ? await T[name](input || {}) : 'error: tool not allowed'; } catch (e) { out = 'error: ' + e.message; } ns.apiReply(id, String(out)); say('tool', 'local API: ' + name); };
  async function showBridges() {
    const p = await ns.privacy.get(), l = await ns.bridges.list();
    const card = h('div', { class: 'cm card' }, h('b', {}, 'Bridges'), h('small', {}, 'Adom Bridge: used automatically when it is running in your menu bar (loopback only). Ask Copilot "list bridge commands" to see what it can do.'));
    l.forEach((b) => card.append(h('div', { class: 'row' }, h('small', {}, `${b.name} · ${b.baseUrl}${b.hasToken ? ' · token saved' : ''}`), h('button', { class: 'ghost', onclick: async () => { await ns.bridges.remove(b.id); card.remove(); say('sys', 'Removed ' + b.name); } }, 'Remove'))));
    const api = h('input', { type: 'checkbox' }); api.checked = !!p.bridgeApi; api.onchange = async () => { await ns.privacy.set('bridgeApi', api.checked); say('sys', api.checked ? 'Local API on. Codex/local tools read the port and token from ~/.northstar/api.json (only you can read that file).' : 'Local API off.'); };
    card.append(h('label', { class: 'sw' }, api, 'Let Codex and other tools on this Mac drive Northstar (local API)'),
      h('div', { class: 'row' }, h('button', { class: 'ghost', onclick: async () => {
        const r = await NS.ask('Add your own bridge (team, studio…). Address must be https:// (or http://127.0.0.1 for this Mac). Token is optional and stored encrypted.', ['Name', 'https://api.example.com/v1', 'Token (optional)']);
        if (!r || !r[0] || !r[1]) return; const res = await ns.bridges.add(r[0], r[1], r[2]); say('sys', res === 'ok' ? 'Added ' + r[0] + '. Ask Copilot to use it.' : res);
      } }, 'Add a bridge'), h('button', { class: 'ghost', onclick: async () => { const t = await ns.bridges.adom('commands'); say('sys', t.startsWith('error') ? t : 'Adom Bridge is reachable.'); } }, 'Test Adom Bridge')));
    log.append(card); log.scrollTop = 1e9;
  }
  async function send(text) {
    if (busy || !text.trim()) return; busy = true; inp.value = ''; say('me', text); hist.push({ role: 'user', content: text });
    try {
      for (let step = 0; step < 8; step++) {
        const wait = say('sys', '…'); const r = await ns.ai.ask(hist); wait.remove();
        if (r.error === 'nokey') { hist.pop(); say('sys', 'Add your API key first (button below).'); break; }
        if (r.error) { hist.pop(); say('sys err', r.error); break; }
        hist.push({ role: 'assistant', content: r.content });
        r.content.filter((b) => b.type === 'text' && b.text).forEach((b) => say('ai', b.text));
        const uses = r.content.filter((b) => b.type === 'tool_use'); if (!uses.length) break;
        const results = [];
        for (const u of uses) {
          let out; try { out = T[u.name] ? await T[u.name](u.input || {}) : 'error: unknown tool'; } catch (e) { out = 'error: ' + e.message; }
          say('tool', u.name.replace(/_/g, ' ') + ' → ' + String(out).split('\n')[0].slice(0, 90)); results.push({ type: 'tool_result', tool_use_id: u.id, content: String(out).slice(0, 4000) });
        }
        hist.push({ role: 'user', content: results });
      }
    } catch (e) { say('sys err', String(e.message || e)); } finally { busy = false; inp.focus(); }
  }
  inp.addEventListener('keydown', (e) => { if (e.key === 'Enter') send(inp.value); });
  async function showMods() {
    const ms = await ns.mods.list(); if (!ms.length) return say('sys', 'No mods yet. Ask me to change something about the browser.');
    ms.forEach((m) => { const c = h('div', { class: 'cm card' }, h('b', {}, m.name + ' (' + m.id + ')'), h('small', {}, m.description), h('div', { class: 'row' },
      h('button', { class: 'ghost', onclick: async () => { m.on = !m.on; await ns.mods.toggle(m.id, m.on); t.textContent = m.on ? 'Turn off' : 'Turn on'; } }, ''), h('button', { class: 'ghost', onclick: async () => { await ns.mods.remove(m.id); c.remove(); } }, 'Delete')));
      const t = c.querySelector('button'); t.textContent = m.on ? 'Turn off' : 'Turn on'; log.append(c); });
    say('sys', 'JS from a mod stays active until you restart. If the UI ever breaks: menu bar Copilot > Safe Mode, or run: bash run.sh --safe');
  }
})();
