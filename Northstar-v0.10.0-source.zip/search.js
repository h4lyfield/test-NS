(() => {
const $ = (s) => document.querySelector(s);
const LS = (k, d) => { try { return JSON.parse(localStorage.getItem(k)) ?? d; } catch { return d; } };
const ENGINES = [
  { id: 'ddg', name: 'DuckDuckGo', url: 'https://duckduckgo.com/?q=' }, { id: 'brave', name: 'Brave Search', url: 'https://search.brave.com/search?q=' },
  { id: 'startpage', name: 'Startpage', url: 'https://www.startpage.com/do/search?q=' }, { id: 'google', name: 'Google', url: 'https://www.google.com/search?q=' },
  { id: 'bing', name: 'Bing', url: 'https://www.bing.com/search?q=' }, { id: 'ecosia', name: 'Ecosia', url: 'https://www.ecosia.org/search?q=' },
  { id: 'qwant', name: 'Qwant', url: 'https://www.qwant.com/?q=' }, { id: 'mojeek', name: 'Mojeek', url: 'https://www.mojeek.com/search?q=' },
];
let engine = LS('engine', 'ddg');
const eng = () => ENGINES.find((e) => e.id === engine) || ENGINES[0];
NS.engineUrl = () => eng().url;
$('#addr').placeholder = 'Search, type an address, or use !yt !g !w !gh !sc !ytm';

// ---- instant answers (all computed on this Mac) ----
function calc(src) {
  const s = src.replace(/[\s,]/g, ''); let i = 0; const pk = () => s[i];
  const num = () => { const m = s.slice(i).match(/^\d*\.?\d+/); if (!m) throw 0; i += m[0].length; return parseFloat(m[0]); };
  const atom = () => { if (pk() === '(') { i++; const v = add(); if (pk() !== ')') throw 0; i++; return v; } if (pk() === '-') { i++; return -atom(); } if (pk() === '+') { i++; return atom(); } return num(); };
  const pow = () => { const b = atom(); if (pk() === '^') { i++; return Math.pow(b, pow()); } return b; };
  const mul = () => { let v = pow(); while ('*/%'.includes(pk() || 'x')) { const o = s[i++], r = pow(); v = o === '*' ? v * r : o === '/' ? v / r : v % r; } return v; };
  const add = () => { let v = mul(); while (pk() === '+' || pk() === '-') { const o = s[i++], r = mul(); v = o === '+' ? v + r : v - r; } return v; };
  const v = add(); if (i !== s.length || !isFinite(v)) throw 0; return v;
}
NS.calc = calc;
const copy = (t) => navigator.clipboard.writeText(t).catch(() => {});
function instant(q) {
  const out = [], l = q.toLowerCase();
  if (/^[\d\s+\-*/().%^,]+$/.test(q) && /[+\-*/^%]/.test(q)) { try { const v = parseFloat(calc(q).toPrecision(12)); out.push({ label: '= ' + v, sub: 'Calculator · Enter copies (% = remainder)', run: () => copy(String(v)) }); } catch { /* not math */ } }
  if (l === 'pw' || l === 'password') { const a = new Uint32Array(20); crypto.getRandomValues(a); const cs = 'abcdefghijkmnpqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ23456789!@#$%&*'; const p = [...a].map((n) => cs[n % cs.length]).join(''); out.push({ label: p, sub: 'New password · Enter copies', run: () => copy(p) }); }
  if (l === 'uuid') { const u = crypto.randomUUID(); out.push({ label: u, sub: 'New UUID · Enter copies', run: () => copy(u) }); }
  if (l === 'flip') out.push({ label: Math.random() < .5 ? 'Heads' : 'Tails', sub: 'Coin flip', run: () => {} });
  if (l === 'roll') out.push({ label: String(1 + Math.floor(Math.random() * 6)), sub: 'Six-sided die', run: () => {} });
  if (l === 'time' || l === 'date') out.push({ label: new Date().toLocaleString([], { dateStyle: 'full', timeStyle: 'short' }), sub: 'Your Mac clock', run: () => {} });
  return out;
}

// ---- search everything on this Mac: tabs, rail sites, music ----
function local(q) {
  const words = q.toLowerCase().split(/\s+/), hit = (s) => words.every((w) => s.toLowerCase().includes(w)), out = [];
  NS.tabs().filter((t) => !t.priv && t.url && hit(t.title + ' ' + t.url)).slice(0, 3).forEach((t) => out.push({ label: t.title, sub: 'Open tab', run: () => NS.select(t) }));
  NS.sites().filter((s) => hit(s.name + ' ' + s.url)).slice(0, 2).forEach((s) => out.push({ label: s.name, sub: 'Rail site', run: () => NS.go(s.url) }));
  (NS.bookmarks ? NS.bookmarks() : []).filter((b) => hit(b.title + ' ' + b.url)).slice(0, 3).forEach((b) => out.push({ label: b.title, sub: 'Bookmark', run: () => NS.go(b.url) }));
  (NS.history ? NS.history() : []).filter((b) => hit(b.title + ' ' + b.url)).slice(0, 3).forEach((b) => out.push({ label: b.title, sub: 'History', run: () => NS.go(b.url) }));
  const m = NS.musicData && NS.musicData();
  if (m) {
    const seen = new Set(), all = [...m.favorites.map((t) => [t, 'Favorite']), ...m.playlists.flatMap((p) => p.tracks.map((t) => [t, 'Playlist · ' + p.name])), ...m.history.map((t) => [t, 'History'])];
    all.filter(([t]) => hit(t.title + ' ' + t.artist)).forEach(([t, k]) => { const key = t.svc + t.title + t.artist; if (seen.has(key) || seen.size >= 4) return; seen.add(key); out.push({ label: t.title + (t.artist ? ' — ' + t.artist : ''), sub: 'Music · ' + k, run: () => NS.musicOpenTrack(t) }); });
  }
  return out;
}

// ---- suggestion dropdown shared by the address bar and the hub ----
function wire(input, box) {
  let items = [], idx = -1, token = 0, timer = 0;
  const pick = (it) => { box.classList.add('hide'); it.run(); };
  const paint = () => { box.innerHTML = ''; items.forEach((it, i) => box.append(h('div', { class: 'si' + (i === idx ? ' on' : ''), onmousedown: (e) => { e.preventDefault(); pick(it); } }, h('b', {}, it.label), it.sub ? h('small', {}, it.sub) : ''))); box.classList.toggle('hide', !items.length); };
  const build = (q) => {
    const my = ++token; q = q.trim(); idx = -1; clearTimeout(timer); if (!q) { items = []; return paint(); }
    const tail = { label: `Search ${eng().name} for “${q}”`, sub: '', run: () => NS.go(q) };
    items = [...instant(q), ...local(q), tail]; paint();
    timer = setTimeout(async () => { const sug = await ns.suggest(q); if (my !== token || !sug.length) return; items = [...items.slice(0, -1), ...sug.map((s) => ({ label: s, sub: 'suggestion', run: () => NS.go(s) })), tail]; paint(); }, 180);
  };
  input.addEventListener('input', () => build(input.value));
  input.addEventListener('keydown', (e) => {
    if (e.key === 'ArrowDown' || e.key === 'ArrowUp') { if (!items.length) return; e.preventDefault(); idx = (idx + (e.key === 'ArrowDown' ? 1 : -1) + items.length) % items.length; paint(); }
    else if (e.key === 'Escape') box.classList.add('hide');
    else if (e.key === 'Enter') { if (idx >= 0 && items[idx]) { e.stopImmediatePropagation(); e.preventDefault(); pick(items[idx]); } else { box.classList.add('hide'); if (input.id === 'hsearch') NS.go(input.value); } }
  }, true);
  input.addEventListener('blur', () => setTimeout(() => box.classList.add('hide'), 120));
}
wire($('#addr'), $('#sug'));

// ---- the search hub (new-tab page) ----
NS.drawHome = () => {
  const hm = $('#home'); hm.innerHTML = '';
  const input = h('input', { id: 'hsearch', placeholder: `Search with ${eng().name}, or type an address`, spellcheck: 'false' }), box = h('div', { class: 'sug hide' });
  const pills = h('div', { class: 'pills' }, ENGINES.map((e) => h('button', { class: 'pill' + (e.id === engine ? ' on' : ''), title: 'Use ' + e.name + ' for searches', onclick: () => { engine = e.id; localStorage.setItem('engine', JSON.stringify(e.id)); NS.drawHome(); } }, e.name)));
  const tiles = h('div', { class: 'tiles' }, NS.sites().map((s) => h('div', { class: 'tile', onclick: () => NS.go(s.url) }, NS.siteIcon(s), s.name)));
  hm.append(h('div', { class: 'hub' }, h('h1', {}, 'Northstar'), h('p', { class: 'tag' }, 'Search the web, your tabs and your music from one box. No ads, no tracking from us.'), h('div', { class: 'hbox' }, input, box), pills, tiles));
  wire(input, box); if (!NS.cur() || !NS.cur().url) setTimeout(() => input.focus(), 50);
};

// ---- vertical tabs + split view ----
const main = $('#main'), setVt = (on) => { main.classList.toggle('vt', on); localStorage.setItem('vt', JSON.stringify(on)); };
setVt(LS('vt', false));
NS.cmds.vtabs = () => setVt(!main.classList.contains('vt'));
NS.cmds.split = () => {
  if (NS.partner) NS.partner = null;
  else { if (NS.tabs().length < 2) NS.newTab(); const t = NS.tabs(), c = NS.cur(); NS.partner = t[(t.indexOf(c) + 1) % t.length]; if (NS.partner === c) NS.partner = null; }
  NS.select(NS.cur());
};
$('#bSplit').innerHTML = ic('columns'); $('#bVt').innerHTML = ic('vtabs'); $('#bSplit').onclick = NS.cmds.split; $('#bVt').onclick = NS.cmds.vtabs;

// ---- privacy panel extras ----
async function extra() { const p = await ns.privacy.get(); $('#pSuggest').checked = !!p.suggest; $('#pListN').textContent = `${p.listSize || 0} domains in list`; }
$('#bShield').addEventListener('click', extra);
$('#pSuggest').onchange = (e) => ns.privacy.set('suggest', e.target.checked);
$('#pList').onclick = async () => { const b = $('#pList'); b.textContent = 'Downloading…'; try { await ns.privacy.updateList(); } catch { $('#pListN').textContent = 'Download failed'; } b.textContent = 'Update blocklist (NOT local)'; extra(); };
NS.drawHome();
})();
