(() => {
const $ = (s) => document.querySelector(s);
const SERVICES = [
  { id: 'ytm', name: 'YouTube Music', host: 'music.youtube.com', home: 'https://music.youtube.com', search: (q) => 'https://music.youtube.com/search?q=' + q },
  { id: 'sc', name: 'SoundCloud', host: 'soundcloud.com', home: 'https://soundcloud.com', search: (q) => 'https://soundcloud.com/search?q=' + q },
  { id: 'yt', name: 'YouTube', host: 'www.youtube.com|youtube.com|m.youtube.com', home: 'https://www.youtube.com', search: (q) => 'https://www.youtube.com/results?search_query=' + q },
  { id: 'sp', name: 'Spotify', host: 'open.spotify.com', home: 'https://open.spotify.com', search: (q) => 'https://open.spotify.com/search/' + q, drm: true },
  { id: 'am', name: 'Apple Music', host: 'music.apple.com', home: 'https://music.apple.com', search: (q) => 'https://music.apple.com/search?term=' + q, drm: true },
];
const svcById = (id) => SERVICES.find((s) => s.id === id);
const svcOf = (url) => { try { const hn = new URL(url).hostname; return SERVICES.find((s) => s.host.split('|').includes(hn)); } catch { return null; } };
let data = { history: [], favorites: [], playlists: [] }, np = null, curSvc = 'ytm', tab = 'player', openPl = null, lastKey = '', seeking = false, filter = '';
const views = {};
NS.musicViews = () => Object.values(views);
NS.musicData = () => data;
const save = () => ns.vault.set('music', data);
const keyOf = (t) => `${t.svc}|${t.title}|${t.artist}`;

// ---- what's playing anywhere (tabs, side panel, music hub) ----
const POLL = `(()=>{const m=navigator.mediaSession,md=m&&m.metadata,e=document.querySelector('video,audio');if(!e)return null;
const art=md&&md.artwork&&md.artwork.length?md.artwork[md.artwork.length-1].src:'';
return{title:(md&&md.title)||document.title.replace(/ - YouTube$/,''),artist:(md&&md.artist)||'',art,playing:!e.paused&&!e.ended,t:e.currentTime||0,d:isFinite(e.duration)?e.duration:0,vol:e.volume,url:location.href,host:location.hostname}})()`;
const run = (wv, code) => wv.executeJavaScript(code).catch(() => false);
const SEL = { next: { 'music.youtube.com': '.next-button', 'soundcloud.com': '.skipControl__next', 'open.spotify.com': '[data-testid="control-button-skip-forward"]', 'youtube.com': '.ytp-next-button' },
  prev: { 'music.youtube.com': '.previous-button', 'soundcloud.com': '.skipControl__previous', 'open.spotify.com': '[data-testid="control-button-skip-back"]', 'youtube.com': '.ytp-prev-button' } };
function skipCode(kind, host) {
  const k = Object.keys(SEL[kind]).find((x) => host.includes(x)); const word = kind === 'next' ? 'next' : 'previous';
  return `(()=>{const s=${JSON.stringify(k ? SEL[kind][k] : null)};let b=s&&document.querySelector(s);if(!b)b=document.querySelector('[aria-label*="${word}" i],[title*="${word}" i]');
if(b){b.click();return true}const e=document.querySelector('video,audio');if(e){e.currentTime=${kind === 'next' ? '(e.duration||0)' : '0'}}return false})()`;
}
const TOGGLE = '(()=>{const e=document.querySelector("video,audio");if(e){e.paused?e.play():e.pause()}})()';
const PAUSE = '(()=>{const e=document.querySelector("video,audio");e&&e.pause()})()';
async function poll() {
  const res = [];
  await Promise.all(NS.allViews().map(async (wv) => { if (!wv.__ready) return; try { const r = await wv.executeJavaScript(POLL); if (r) { r.wv = wv; res.push(r); } } catch { /* view not ready */ } }));
  const playing = res.filter((r) => r.playing);
  const pick = playing.find((r) => np && r.wv === np.wv) || playing[0] || res.find((r) => np && r.wv === np.wv && r.title) || null;
  np = pick; if (np) { const s = svcOf(np.url); np.svc = s ? s.id : np.host; }
  if (np && np.playing) { const k = keyOf(np); if (k !== lastKey && np.title) { lastKey = k; data.history.unshift({ svc: np.svc, title: np.title, artist: np.artist, url: np.url, art: np.art, ts: Date.now() }); data.history.length = Math.min(data.history.length, 500); save(); if (tab === 'history') renderList(); } }
  paintBar();
}
const isFav = () => np && data.favorites.some((f) => f.key === keyOf(np));
const fmt = (s) => { s = Math.floor(s || 0); return Math.floor(s / 60) + ':' + String(s % 60).padStart(2, '0'); };

// ---- Now Playing bar ----
const bar = h('div', { id: 'nowbar', class: 'hide' });
const art = h('img', { class: 'art' }), tt = h('b'), ta = h('small');
const bPrev = h('button', { class: 'ib ico', html: ic('prev'), title: 'Previous', onclick: () => np && run(np.wv, skipCode('prev', np.host)) });
const bPlay = h('button', { class: 'pp ico', title: 'Play / pause', onclick: () => np && run(np.wv, TOGGLE).then(() => setTimeout(poll, 300)) });
const bNext = h('button', { class: 'ib ico', html: ic('next'), title: 'Next', onclick: () => np && run(np.wv, skipCode('next', np.host)) });
const prog = h('input', { type: 'range', min: 0, max: 1000, value: 0, oninput: () => { seeking = true; }, onchange: () => { if (np) run(np.wv, `(()=>{const e=document.querySelector('video,audio');if(e&&e.duration)e.currentTime=e.duration*${prog.value / 1000}})()`); seeking = false; } });
const tm = h('small', {}, '0:00 / 0:00');
const vol = h('input', { type: 'range', min: 0, max: 100, value: 100, title: 'Volume', oninput: () => np && run(np.wv, `(()=>{const e=document.querySelector('video,audio');if(e)e.volume=${vol.value / 100}})()`) });
const bFav = h('button', { class: 'ib ico fav', html: ic('heart'), title: 'Favorite', onclick: () => { if (!np) return; const i = data.favorites.findIndex((f) => f.key === keyOf(np)); if (i >= 0) data.favorites.splice(i, 1); else data.favorites.unshift({ key: keyOf(np), svc: np.svc, title: np.title, artist: np.artist, url: np.url, art: np.art, ts: Date.now() }); save(); paintBar(); renderList(); } });
const bList = h('button', { class: 'ib ico', html: ic('list'), title: 'Add to a playlist', onclick: (e) => { e.stopPropagation(); if (!np) return; const items = data.playlists.map((p) => [p.name, () => addTo(p.id)]); items.push(['New playlist…', async () => { const r = await NS.ask('New playlist', ['Name']); if (r && r[0]) { const p = newPl(r[0]); addTo(p.id); } }]); NS.ctx(e.clientX - 120, e.clientY - 40 * items.length - 10, items); } });
const chipsBar = h('div', { class: 'sw2' }, SERVICES.map((s) => h('button', { class: 'logo', 'data-id': s.id, title: 'Move this song to ' + s.name, html: logoFor(s.home), onclick: () => switchTo(s.id) })), bFav, bList, vol);
bar.append(h('div', { class: 'meta' }, art, h('div', { class: 'tt' }, tt, ta)), h('div', { class: 'mid' }, h('div', { class: 'tr' }, bPrev, bPlay, bNext), h('div', { class: 'tr', style: 'width:100%;gap:8px' }, prog, tm)), chipsBar);
$('#main').append(bar);
function paintBar() {
  bar.classList.toggle('hide', !np); if (!np) return;
  tt.textContent = np.title || 'Unknown'; ta.textContent = [np.artist, (svcById(np.svc) || {}).name || np.host].filter(Boolean).join(' · ');
  if (np.art) { art.src = np.art; art.style.visibility = 'visible'; } else art.style.visibility = 'hidden';
  bPlay.innerHTML = ic(np.playing ? 'pause' : 'play'); bFav.classList.toggle('on', !!isFav());
  if (!seeking) { prog.value = np.d ? (np.t / np.d) * 1000 : 0; tm.textContent = `${fmt(np.t)} / ${fmt(np.d)}`; }
  chipsBar.querySelectorAll('.logo').forEach((b) => b.classList.toggle('cur', b.dataset.id === np.svc));
}
function newPl(name) { const p = { id: Date.now().toString(36), name, tracks: [] }; data.playlists.push(p); save(); return p; }
function addTo(id) { const p = data.playlists.find((x) => x.id === id); if (!p || !np) return; if (!p.tracks.some((t) => keyOf(t) === keyOf(np))) p.tracks.push({ svc: np.svc, title: np.title, artist: np.artist, url: np.url, art: np.art, ts: Date.now() }); save(); renderList(); }

// ---- switching service while playing ----
const FIRST = {
  ytm: "(()=>{const r=document.querySelector('ytmusic-responsive-list-item-renderer');const b=r&&r.querySelector('ytmusic-play-button-renderer');if(b){b.click();return true}return false})()",
  sc: "(()=>{const a=document.querySelector('.searchList__item .sc-button-play,.soundList__item .sc-button-play');if(a){a.click();return true}return false})()",
  yt: "(()=>{const a=document.querySelector('ytd-video-renderer a#thumbnail');if(a){a.click();return true}return false})()",
};
function tryPlay(id, n = 0) {
  if (!FIRST[id] || n > 5) return;
  setTimeout(async () => { let ok = false; try { ok = await views[id].executeJavaScript(FIRST[id]); } catch { /* not loaded yet */ } if (!ok) tryPlay(id, n + 1); else setTimeout(poll, 800); }, 2500);
}
function switchTo(id) {
  if (!np || id === np.svc) return; const s = svcById(id), q = encodeURIComponent((np.title + ' ' + np.artist).trim());
  run(np.wv, PAUSE); loadIn(id, s.search(q), true);
}

// ---- Music hub ----
const root = $('#music');
const chips = h('div', { class: 'chips' }, SERVICES.map((s) => h('button', { class: 'chip', 'data-id': s.id, title: s.name + (s.drm ? ' — needs protected-content (DRM) playback, which this build may not have' : ''), onclick: () => { curSvc = s.id; show('player'); } }, h('span', { class: 'logo', html: logoFor(s.home) }), s.name)));
const q = h('input', { class: 'msearch', placeholder: 'Search in the selected service, then press Enter', onkeydown: (e) => { if (e.key === 'Enter' && q.value.trim()) { loadIn(curSvc, svcById(curSvc).search(encodeURIComponent(q.value.trim())), false); } } });
const tabsEl = h('div', { class: 'mtabs' }, [['player', 'Player'], ['history', 'History'], ['favorites', 'Favorites'], ['playlists', 'Playlists']].map(([t, l]) => h('button', { 'data-t': t, onclick: () => { openPl = null; show(t); } }, l)));
const mViews = h('div', { id: 'mViews' }), mList = h('div', { id: 'mList', class: 'hide' });
root.append(h('div', { class: 'mhead' }, chips, q), tabsEl, mViews, mList);
function ensureView(id) { if (!views[id]) { views[id] = NS.mk(svcById(id).home); mViews.append(views[id]); } return views[id]; }
function loadIn(id, url, play) { curSvc = id; const v = ensureView(id); v.src = url; setOpen(true); show('player'); if (play) tryPlay(id); }
function show(t) {
  tab = t; curSvc = curSvc || 'ytm';
  tabsEl.querySelectorAll('button').forEach((b) => b.classList.toggle('on', b.dataset.t === t));
  chips.querySelectorAll('.chip').forEach((b) => b.classList.toggle('on', b.dataset.id === curSvc && t === 'player'));
  const player = t === 'player'; mViews.classList.toggle('hide', !player); mList.classList.toggle('hide', player);
  if (player) { const v = ensureView(curSvc); Object.entries(views).forEach(([id, w]) => w.classList.toggle('hide', id !== curSvc)); void v; } else renderList();
}
function setOpen(on) { root.classList.toggle('hide', !on); $('#stage').classList.toggle('mopen', on); $('#bMusic').classList.toggle('on', on); if (on && !mViews.children.length) show(tab); }
$('#bMusic').onclick = () => setOpen(root.classList.contains('hide'));

function trackUrl(t) {
  try { const u = new URL(t.url), p = u.pathname.split('/').filter(Boolean);
    if (t.svc === 'ytm' || t.svc === 'yt') return u.pathname === '/watch' ? t.url : svcById(t.svc).search(encodeURIComponent(t.title + ' ' + t.artist));
    if (t.svc === 'sc') return p.length >= 2 && p[0] !== 'search' ? t.url : svcById('sc').search(encodeURIComponent(t.title + ' ' + t.artist));
    if (t.svc === 'sp') return p[0] === 'track' ? t.url : svcById('sp').search(encodeURIComponent(t.title + ' ' + t.artist));
  } catch { /* fall through */ }
  const s = svcById(t.svc); return s ? s.search(encodeURIComponent(t.title + ' ' + t.artist)) : t.url;
}
NS.musicOpenTrack = (t) => openTrack(t);
const openTrack = (t) => { const id = svcById(t.svc) ? t.svc : curSvc; loadIn(id, trackUrl(t), true); };
const btn = (name, title, fn) => h('button', { class: 'ib ico', html: ic(name), title, onclick: (e) => { e.stopPropagation(); fn(e); } });
function row(t, ...acts) {
  const s = svcById(t.svc);
  return h('div', { class: 'mrow' }, h('span', { class: 'logo', html: s ? logoFor(s.home) : '' }), h('div', { class: 'mt', onclick: () => openTrack(t) }, h('b', {}, t.title || 'Unknown'), h('small', {}, t.artist || '')),
    h('small', { class: 'when' }, t.ts ? new Date(t.ts).toLocaleString([], { dateStyle: 'short', timeStyle: 'short' }) : ''), acts);
}
function renderList() {
  if (tab === 'player') return; mList.innerHTML = '';
  if (tab === 'history') {
    mList.append(h('input', { class: 'mfilter', placeholder: 'Search your history', value: filter, oninput: (e) => { filter = e.target.value; renderList(); const i = mList.querySelector('.mfilter'); i.focus(); i.setSelectionRange(filter.length, filter.length); } }),
      btn('trash', 'Clear history', async () => { const r = await NS.ask('Clear music history? Type YES.', ['YES']); if (r && r[0].toUpperCase() === 'YES') { data.history = []; save(); renderList(); } }));
    const f = filter.toLowerCase(), items = data.history.filter((t) => !f || (t.title + ' ' + t.artist).toLowerCase().includes(f)).slice(0, 200);
    if (!items.length) mList.append(h('div', { class: 'empty' }, 'Nothing here yet. Songs you play show up automatically.'));
    items.forEach((t) => mList.append(row(t, btn('heart', 'Favorite', () => { if (!data.favorites.some((x) => x.key === keyOf(t))) { data.favorites.unshift({ ...t, key: keyOf(t) }); save(); } }))));
  } else if (tab === 'favorites') {
    if (!data.favorites.length) mList.append(h('div', { class: 'empty' }, 'Tap the heart on the bar below to save songs here.'));
    data.favorites.forEach((t) => mList.append(row(t, btn('close', 'Remove', () => { data.favorites = data.favorites.filter((x) => x !== t); save(); renderList(); paintBar(); }))));
  } else if (tab === 'playlists') {
    const p = openPl && data.playlists.find((x) => x.id === openPl);
    if (p) {
      mList.append(h('div', { class: 'mrow' }, btn('back', 'All playlists', () => { openPl = null; renderList(); }), h('b', { style: 'flex:1' }, p.name),
        btn('trash', 'Delete playlist', async () => { const r = await NS.ask(`Delete "${p.name}"? Type YES.`, ['YES']); if (r && r[0].toUpperCase() === 'YES') { data.playlists = data.playlists.filter((x) => x !== p); openPl = null; save(); renderList(); } })));
      if (!p.tracks.length) mList.append(h('div', { class: 'empty' }, 'Empty. Use the list button on the bar below to add the song that is playing.'));
      p.tracks.forEach((t) => mList.append(row(t, btn('close', 'Remove', () => { p.tracks = p.tracks.filter((x) => x !== t); save(); renderList(); }))));
    } else {
      mList.append(h('button', { class: 'cta ghost', onclick: async () => { const r = await NS.ask('New playlist', ['Name']); if (r && r[0]) { newPl(r[0]); renderList(); } } }, '+ New playlist'), h('div', { style: 'height:12px' }));
      data.playlists.forEach((x) => mList.append(h('div', { class: 'pl', onclick: () => { openPl = x.id; renderList(); } }, h('b', {}, x.name), h('small', {}, x.tracks.length + ' songs'))));
    }
  }
}
NS.musicCmd = (n) => {
  if (n === 'music-view') setOpen(root.classList.contains('hide'));
  else if (!np) return; else if (n === 'music-toggle') bPlay.click(); else if (n === 'music-next') bNext.click(); else if (n === 'music-prev') bPrev.click();
};
ns.vault.get('music').then((d) => { if (d) { data = Object.assign(data, d); } renderList(); });
setInterval(poll, 2500);
})();
