const { contextBridge, ipcRenderer } = require('electron');
const inv = (c, ...a) => ipcRenderer.invoke(c, ...a);
contextBridge.exposeInMainWorld('ns', {
  on: (cb) => ipcRenderer.on('cmd', (_e, n, a) => cb(n, a)),
  top: () => inv('top'), setOpacity: (v) => inv('opacity', v), restart: () => inv('restart'),
  apiReply: (id, r) => ipcRenderer.send('api:reply', id, r),
  bridges: { list: () => inv('bridges:list'), add: (n, u, t) => inv('bridges:add', n, u, t), remove: (i) => inv('bridges:remove', i), http: (i, m, p, b) => inv('bridges:http', i, m, p, b), adom: (c, a, ap) => inv('bridge:adom', c, a, ap) },
  ai: { ask: (m) => inv('ai:ask', m), hasKey: () => inv('ai:hasKey'), setKey: (k) => inv('ai:setKey', k), clearKey: () => inv('ai:clearKey') },
  mods: { list: () => inv('mods:list'), save: (m) => inv('mods:save', m), toggle: (i, o) => inv('mods:toggle', i, o), remove: (i) => inv('mods:remove', i) }, camo: () => inv('camo'),
  reveal: (p) => ipcRenderer.send('reveal', p),
  tool: (n) => ipcRenderer.send('tool', n),
  vault: { get: (k) => inv('vault:get', k), set: (k, v) => inv('vault:set', k, v) },
  suggest: (q) => inv('suggest', q),
  privacy: { updateList: () => inv('privacy:updateList'), get: () => inv('privacy:get'), set: (k, v) => inv('privacy:set', k, v), clear: () => inv('privacy:clear') },
});
