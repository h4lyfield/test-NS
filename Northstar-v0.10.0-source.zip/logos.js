const S = (b) => `<svg viewBox="0 0 24 24">${b}</svg>`;
window.ICONS = {
  back: '<path d="M15 5l-7 7 7 7"/>', fwd: '<path d="M9 5l7 7-7 7"/>', reload: '<path d="M20 11a8 8 0 1 0-2.3 5.7M20 4v7h-7"/>', plus: '<path d="M12 5v14M5 12h14"/>', close: '<path d="M6 6l12 12M18 6L6 18"/>',
  shield: '<path d="M12 3l7 3v5c0 5-3.2 8.4-7 10-3.8-1.6-7-5-7-10V6z"/>', music: '<path d="M9 18V6l10-2v12"/><circle cx="6.5" cy="18" r="2.5"/><circle cx="16.5" cy="16" r="2.5"/>',
  pin: '<path d="M9 4h6l-1 6 3 3H7l3-3zM12 13v7"/>', power: '<path d="M12 3v8M6.3 6.3a8 8 0 1 0 11.4 0"/>', pulse: '<path d="M3 12h4l2-6 4 12 2-6h6"/>',
  gear: '<circle cx="12" cy="12" r="3"/><path d="M12 2v3M12 19v3M2 12h3M19 12h3M4.9 4.9L7 7M17 17l2.1 2.1M19.1 4.9L17 7M7 17l-2.1 2.1"/>',
  heart: '<path d="M12 20s-7-4.4-7-10a4 4 0 0 1 7-2.5A4 4 0 0 1 19 10c0 5.6-7 10-7 10z"/>', list: '<path d="M8 6h12M8 12h12M8 18h12M4 6h.01M4 12h.01M4 18h.01"/>',
  search: '<circle cx="11" cy="11" r="6"/><path d="M20 20l-4.5-4.5"/>', palette: '<path d="M12 3a9 9 0 1 0 0 18c1.5 0 2-1 1.5-2s0-2 1.5-2h2a4 4 0 0 0 4-4c0-5-4.5-10-9-10z"/><circle cx="8" cy="11" r="1"/><circle cx="12" cy="7.5" r="1"/><circle cx="16" cy="11" r="1"/>',
  lock: '<rect x="5" y="11" width="14" height="9" rx="2"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/>', clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>', trash: '<path d="M5 7h14M10 7V4h4v3M7 7l1 13h8l1-13"/>',
  prev: '<path d="M18 5v14L8 12zM6 5v14"/>', next: '<path d="M6 5v14l10-7zM18 5v14"/>', play: '<path d="M7 4v16l13-8z"/>', pause: '<path d="M7 4h4v16H7zM13 4h4v16h-4z"/>',
  columns: '<rect x="3" y="4" width="18" height="16" rx="2"/><path d="M12 4v16"/>', vtabs: '<rect x="3" y="4" width="18" height="16" rx="2"/><path d="M9 4v16"/>',
  download: '<path d="M12 4v11M7 11l5 5 5-5M5 20h14"/>',
  star: '<path d="M12 2l2.5 7.5H22l-6 4.5 2.3 7.5L12 17l-6.3 4.5L8 14 2 9.5h7.5z"/>', mask: '<path d="M3 9c3-3 15-3 18 0v3c0 4-3 6-6 6-2 0-2-2-3-2s-1 2-3 2c-3 0-6-2-6-6z"/><circle cx="8.5" cy="11.5" r="1.2"/><circle cx="15.5" cy="11.5" r="1.2"/>',
};
const FILLED = new Set(['prev', 'next', 'play', 'pause', 'star']);
window.ic = (n, on) => `<svg viewBox="0 0 24 24" class="${FILLED.has(n) || on ? 'f' : ''}">${ICONS[n] || ''}</svg>`;
window.h = (t, p = {}, ...k) => {
  const e = document.createElement(t);
  for (const [a, v] of Object.entries(p)) { if (a === 'class') e.className = v; else if (a === 'html') e.innerHTML = v; else if (a.startsWith('on')) e.addEventListener(a.slice(2), v); else e.setAttribute(a, v); }
  k.flat().forEach((c) => e.append(c && c.nodeType ? c : document.createTextNode(c === false || c == null ? '' : c)));
  return e;
};
// Simplified marks that identify each service (approximations, not official artwork)
const L = {
  youtube: S('<rect x="1" y="5" width="22" height="14" rx="4.5" fill="#ff0033"/><path d="M10 9l5.2 3-5.2 3z" fill="#fff"/>'),
  ytmusic: S('<circle cx="12" cy="12" r="11" fill="#ff0033"/><circle cx="12" cy="12" r="6.4" fill="none" stroke="#fff" stroke-width="1.6"/><path d="M10.3 9.3l4.6 2.7-4.6 2.7z" fill="#fff"/>'),
  spotify: S('<circle cx="12" cy="12" r="11" fill="#1db954"/><g fill="none" stroke="#0b0d12" stroke-width="1.8" stroke-linecap="round"><path d="M6 9.4c4-1.2 8.2-.9 12 1.3"/><path d="M6.9 12.7c3.4-.9 6.6-.6 9.4 1.1"/><path d="M7.7 15.7c2.7-.6 5-.4 7.2.8"/></g>'),
  soundcloud: S('<rect x="1" y="1" width="22" height="22" rx="6" fill="#ff5500"/><path d="M6.5 16.5h10.8a3 3 0 0 0 .4-6A5 5 0 0 0 8.2 9.9 3.4 3.4 0 0 0 6.5 16.5z" fill="#fff"/>'),
  apple: S('<rect x="1" y="1" width="22" height="22" rx="6" fill="#fa233b"/><path d="M15.6 6v8.1a2.3 2.3 0 1 1-1.3-2V8.4l-4.3 1v6.1a2.3 2.3 0 1 1-1.3-2V8z" fill="#fff"/>'),
  duck: S('<circle cx="12" cy="12" r="11" fill="#de5833"/><circle cx="12" cy="12" r="7.5" fill="#fff"/><circle cx="14.5" cy="10.2" r="1.2" fill="#2d4f8e"/>'),
  google: S('<circle cx="12" cy="12" r="11" fill="#fff"/><text x="12" y="17" text-anchor="middle" font-size="15" font-weight="700" font-family="Arial" fill="#4285f4">G</text>'),
};
window.logoFor = (url) => {
  let h2 = ''; try { h2 = new URL(url).hostname; } catch { return null; }
  if (h2 === 'music.youtube.com') return L.ytmusic; if (/(^|\.)youtube\.com$/.test(h2) || h2 === 'youtu.be') return L.youtube;
  if (/spotify\.com$/.test(h2)) return L.spotify; if (/soundcloud\.com$/.test(h2)) return L.soundcloud; if (/music\.apple\.com$/.test(h2)) return L.apple;
  if (/duckduckgo\.com$/.test(h2)) return L.duck; if (/(^|\.)google\.com$/.test(h2)) return L.google; return null;
};
