# Northstar v0.10.0 — handoff to Codex

Electron 33 app, no build step. Run: `bash run.sh`. Files: main.js (privacy, vault, menus), stealth-main.js (runs inside pages), stealth-preload.js (injects it), app.js/search.js/music.js/daily.js/hud.js/glove.js (UI), iwmd.css + glove.css (Data Glove theme).

## What v0.8.0 added
- Ad/tracker blocking: domain list + `/pagead/`-style path rules (third-party only). Blocked scripts/images/CSS get an empty data: stand-in instead of a failed load.
- Cosmetic hiding of leftover ad boxes (main.js `COSMETIC`; bait classes like `.adsbox` are deliberately NOT hidden).
- Fingerprint fuzzing: canvas, WebGL GPU name, audio, CPU/memory counts, Battery API. Deterministic per site per launch; patched functions report `[native code]`.
- `window.adsbygoogle` stand-in for "ad blocker detected" scripts.
- YouTube ad skipping from inside the page.
- Tracking-param stripping (utm_, fbclid, gclid...), pop-up/pop-under holding with an Open button, all toggles persisted in `settings.json`.
- Data Glove UI: boot sequence, hex grid, STREAKS tray label on the rail, readout strip, stealth stats panel, Optical Camo button (cycles 100/70/40% opacity).

## NOT TESTED (no real Electron run was possible)
Only syntax checks plus a fake-DOM smoke test of stealth-main.js. Verify first on a real Mac:
1. `ses.setPreloads` actually runs stealth-preload.js in sandboxed webviews, and `webFrame.executeJavaScript` runs before page scripts (check the "Fuzzed" counter rises on a fingerprint test page).
2. Redirecting blocked requests to `data:` URLs is accepted (if not, they simply fail, same as a block).
3. YouTube skipper (selectors rot quickly; YouTube also shows an anti-adblock dialog).
4. Pop-up holding does not annoy normal cross-site `target=_blank` links (it asks first; may need a user-gesture signal).

## Known gaps / next
- Protections cover the top frame only; embedded player iframes (common on streaming sites) are not covered. Needs `nodeIntegrationInSubFrames` or per-frame preload.
- No real EasyList cosmetic/scriptlet engine; only simple `||domain^` network rules are imported.
- Third-party cookie blocking not implemented (needs a public-suffix list).
- Cannot claim "undetectable": it is an arms race. Nothing hides your IP; use a VPN.
- Still missing vs a daily browser: passwords/autofill, extensions, auto-update, protected-content (DRM) video, default-browser packaging, sync.

## v0.9.0: Copilot (in-app AI)
- Files: ai-core.js (main: system prompt, tool schemas, API call), copilot.js (UI + tool execution), main.js (key storage, mods, safe mode), preload.js (`ns.ai`, `ns.mods`).
- Opens with Cmd+K or the sparkle rail button. Model default `claude-sonnet-5-5` (change in ai-core.js). Needs the owner's own Anthropic API key (console.anthropic.com, pay-per-use; a Claude chat subscription does not work). Key is stored via safeStorage and blocked from the generic vault IPC, so page/mod code cannot read it.
- 16 tools (tabs, rail, theme, privacy toggles, window opacity, built-in commands, mods). Approval cards for: removing rail sites, weakening privacy / enabling suggestions, saving or deleting mods. Private tabs are hidden from the model.
- "Update the browser itself" = mods: CSS/JS saved in userData/mods/*.json, applied at launch. It does NOT edit Northstar's source files. Mod JS runs with full UI access, so the approval card shows the code first.
- Escape hatches that work even if a mod breaks the UI: native menu Copilot > Safe Mode / Turn Off All Mods, `bash run.sh --safe`, and an automatic skip if the previous launch didn't finish within 6s.
- Untested on a real Mac: the live API call, mod injection (`insertCSS` / `executeJavaScript`), `app.relaunch` under run.sh. Mock-tested only: tool loop and approval gates.
- Next ideas: let Copilot read page text (opt-in; prompt-injection risk), streaming replies, mod versioning/undo history, a way to propose edits to source files as a patch file for review in Codex.

## v0.10.0: Bridges
Three ways to connect (Copilot > Bridges button; code in main.js "bridges" block, tools in copilot.js):
1. **Adom Bridge** (documented loopback API, `127.0.0.1:47200`, port from `~/.adom/direct-api-port`; POST /command {app, command, args}; GET /commands). Copilot tools `bridge_list`, `bridge_adom`. Read-only verbs run directly; everything else shows an approval card (extra warning for shell/file/input verbs). Adom itself does NOT gate local callers, so Northstar's card is the only gate.
2. **Own HTTP bridges** (for team/studio services): name + https base URL + optional bearer token. Token encrypted, main-process only, never sent to the UI or the model. Paths restricted to the bridge's origin, redirects refused, non-GET asks first. Tool `bridge_http`.
3. **Local API for Codex / other tools** (off by default, toggle in Bridges): 127.0.0.1, random port + token in `~/.northstar/api.json` (0600). Rejects requests with an Origin header or non-127.0.0.1 Host. Only approval-free tools are allowed (see INBOUND in main.js). Example:
   `P=$(python3 -c "import json,os;d=json.load(open(os.path.expanduser('~/.northstar/api.json')));print(d['port'],d['token'])"); set -- $P; curl -s -H "Authorization: Bearer $2" -d '{"name":"open_tab","input":{"url":"https://example.com"}}' http://127.0.0.1:$1/tool`

Mock-tested (stubbed Electron + fake services): all main-process paths, auth rejections, path/redirect limits. NOT tested against a real Adom Bridge, Teambridge or "Reception Studio": their real endpoints/auth are unknown, so those need their API docs and a real run.
