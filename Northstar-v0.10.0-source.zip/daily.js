(() => {
const $ = (s) => document.querySelector(s);
const LS = (k, d) => { try { return JSON.parse(localStorage.getItem(k)) ?? d; } catch { return d; } };
let bms = [], hist = [], histOn = LS('histOn', false), dls = [], saveT = 0;
const saveB = () => ns.vault.set('bookmarks', bms);
ns.vault.get('bookmarks').then((d) => { bms = d || []; paintBms(); star(); }); ns.vault.get('history').then((d) => { hist = d || []; });
NS.bookmarks = () => bms; NS.history = () => (histOn ? hist : []);

// ---- bookmarks + import ----
const bmbar = h('div', { id: 'bmbar', class: LS('bmbar', true) ? '' : 'hide' }); $('#main').insertBefore(bmbar, $('#stage'));
const file = h('input', { type: 'file', accept: '.html,.htm', style: 'display:none', onchange: async () => { const f = file.files[0]; if (!f) return; const n = importHtml(await f.text()); file.value = ''; NS.ask(`Imported ${n} bookmarks.`, []); } });
function importHtml(txt) {
  const doc = new DOMParser().parseFromString(txt, 'text/html'); let n = 0;
  doc.querySelectorAll('a[href]').forEach((a) => { const u = a.getAttribute('href'); if (bms.length < 5000 && /^https?:/i.test(u) && !bms.some((b) => b.url === u)) { bms.push({ title: (a.textContent || u).trim().slice(0, 120), url: u }); n++; } });
  saveB(); paintBms(); return n;
}
NS.importBookmarks = importHtml;
function paintBms() {
  bmbar.innerHTML = '';
  bms.slice(0, 40).forEach((b) => bmbar.append(h('button', { class: 'bm', title: b.url, onclick: () => NS.go(b.url),
    oncontextmenu: (e) => { e.preventDefault(); NS.ctx(e.clientX, e.clientY, [['Open in new tab', () => NS.newTab(b.url)], ['Remove bookmark', () => { bms = bms.filter((x) => x !== b); saveB(); paintBms(); star(); }]]); } }, b.title)));
  bmbar.append(h('button', { class: 'bm', title: 'Import bookmarks from Safari, Helium or Chrome (exported .html file)', onclick: () => file.click() }, bms.length ? 'Import…' : 'Import bookmarks from a .html export'), file);
}
const starBtn = h('button', { id: 'bStar', class: 'ib ico', html: ic('star'), title: 'Bookmark this page (⌘D)', onclick: () => NS.cmds.bookmark() });
$('#bar').insertBefore(starBtn, $('#bSplit'));
function star() { const t = NS.cur(); starBtn.classList.toggle('on', !!(t && bms.some((b) => b.url === t.url))); }
NS.cmds.bookmark = () => { const t = NS.cur(); if (!t || !t.url || t.priv) return; const i = bms.findIndex((b) => b.url === t.url); if (i >= 0) bms.splice(i, 1); else bms.unshift({ title: t.title, url: t.url }); saveB(); paintBms(); star(); };
NS.cmds.bmbar = () => { bmbar.classList.toggle('hide'); localStorage.setItem('bmbar', JSON.stringify(!bmbar.classList.contains('hide'))); };
setInterval(star, 1500);

// ---- history (OFF unless you turn it on; never records private tabs) ----
NS.onVisit = (t) => {
  if (!histOn || t.priv || !/^https?:/.test(t.url)) return; const u = t.url;
  setTimeout(() => { if (t.url !== u || (hist[0] && hist[0].url === u)) return; hist.unshift({ title: t.title, url: u, ts: Date.now() }); hist.length = Math.min(hist.length, 2000); clearTimeout(saveT); saveT = setTimeout(() => ns.vault.set('history', hist), 2000); }, 1500);
};
$('#pHist').checked = histOn; $('#pHist').onchange = (e) => { histOn = e.target.checked; localStorage.setItem('histOn', JSON.stringify(histOn)); };
$('#pHistClear').onclick = async () => { const r = await NS.ask('Clear browsing history? Type YES.', ['YES']); if (r && r[0].toUpperCase() === 'YES') { hist = []; ns.vault.set('history', hist); } };

// ---- downloads ----
const dlPop = h('div', { id: 'dlpop', class: 'pop hide' }, h('h3', {}, 'Downloads'), h('div', { id: 'dlist' })); $('#stage').append(dlPop); dlPop.onclick = (e) => e.stopPropagation();
const dlBtn = h('button', { class: 'ib ico', html: ic('download'), title: 'Downloads (⇧⌘J)', onclick: (e) => { e.stopPropagation(); dlPop.classList.toggle('hide'); } });
$('#bar').insertBefore(dlBtn, $('#bSplit')); document.addEventListener('click', () => dlPop.classList.add('hide'));
function paintDl() {
  const l = $('#dlist'); l.innerHTML = ''; if (!dls.length) l.append(h('small', {}, 'Nothing downloaded yet. Files go to your Downloads folder.'));
  dls.forEach((d) => l.append(h('div', { class: 'dl' }, h('b', {}, d.name), d.state === 'completed' ? h('button', { class: 'ghost', onclick: () => ns.reveal(d.path) }, 'Show in Finder') : h('small', {}, d.state === 'progressing' ? Math.round((d.got / (d.total || d.got || 1)) * 100) + '%' : d.state),
    d.state === 'progressing' ? h('progress', { max: d.total || 1, value: d.got }) : '')));
}
NS.cmds.dl = (info) => { const i = dls.findIndex((d) => d.id === info.id); if (i < 0) { dls.unshift(info); dlPop.classList.remove('hide'); } else dls[i] = info; paintDl(); };
NS.cmds.downloads = () => dlPop.classList.toggle('hide'); paintDl();

// ---- find in page ----
const fi = h('input', { placeholder: 'Find in page', oninput: () => run(false), onkeydown: (e) => { if (e.key === 'Enter') run(true, !e.shiftKey); else if (e.key === 'Escape') closeFind(); } }), fc = h('small', {});
const findBar = h('div', { id: 'findbar', class: 'pop hide' }, h('div', { class: 'fr' }, fi, fc, h('button', { class: 'ib ico', html: ic('back'), title: 'Previous', onclick: () => run(true, false) }), h('button', { class: 'ib ico', html: ic('fwd'), title: 'Next', onclick: () => run(true, true) }), h('button', { class: 'ib ico', html: ic('close'), onclick: closeFind })));
$('#stage').append(findBar); findBar.onclick = (e) => e.stopPropagation();
function run(next, fwd = true) {
  const t = NS.cur(); if (!t) return; const wv = t.wv, q = fi.value;
  try { if (!wv.__fip) { wv.__fip = true; wv.addEventListener('found-in-page', (e) => { fc.textContent = e.result.matches ? `${e.result.activeMatchOrdinal}/${e.result.matches}` : 'none'; }); }
    if (!q) { wv.stopFindInPage('clearSelection'); fc.textContent = ''; } else wv.findInPage(q, { findNext: next, forward: fwd }); } catch { /* page not ready */ }
}
function closeFind() { findBar.classList.add('hide'); try { NS.cur().wv.stopFindInPage('clearSelection'); } catch { /* ignore */ } }
NS.cmds.find = () => { findBar.classList.remove('hide'); fi.focus(); fi.select(); };

// ---- zoom ----
NS.cmds.zoom = (dir) => { const t = NS.cur(); if (!t) return; try { const z = dir === 0 ? 1 : Math.min(3, Math.max(0.3, t.wv.getZoomFactor() + dir * 0.1)); t.wv.setZoomFactor(z); } catch { /* page not ready */ } };
})();
