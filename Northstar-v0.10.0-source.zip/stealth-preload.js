// Session preload for every web tab. Asks the main process for the stealth script and runs it in the page before the page's own code.
const { webFrame, ipcRenderer } = require('electron');
try {
  if (location.protocol === 'http:' || location.protocol === 'https:') {
    const cfg = ipcRenderer.sendSync('stealth:cfg');
    if (cfg && cfg.code) { webFrame.executeJavaScript(cfg.code); window.addEventListener(cfg.ev, () => ipcRenderer.send('stealth:fp')); }
  }
} catch { /* never break a page because of this */ }
