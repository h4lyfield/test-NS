const { app, BrowserWindow, Menu, ipcMain, session, safeStorage, shell } = require('electron');
const { execFile } = require('child_process');
const fs = require('fs'), path = require('path');
app.userAgentFallback = app.userAgentFallback.replace(/ Electron\/\S+/, '').replace(/ northstar\/\S+/i, '');
let win;
const send = (c, a) => { if (win && !win.isDestroyed()) win.webContents.send('cmd', c, a); };

// ---------- privacy (plain, readable, user-toggleable) ----------
const P = { bridgeApi: false, https: true, block: true, suggest: false, stealth: true, strip: true, popups: true, cosmetic: true, ytads: true };
const S = { blocked: 0, popups: 0, stripped: 0, fp: 0 };   // live counters, this session only
const sfile = () => path.join(app.getPath('userData'), 'settings.json');
const loadSettings = () => { try { const j = JSON.parse(fs.readFileSync(sfile(), 'utf8')); for (const k in P) if (typeof j[k] === 'boolean') P[k] = j[k]; } catch { /* first run */ } };
const saveSettings = () => { try { fs.writeFileSync(sfile(), JSON.stringify(P)); } catch { /* ignore */ } };
const TRACK = /^(utm_[a-z_]+|fbclid|gclid|gclsrc|dclid|msclkid|mc_eid|mc_cid|igshid|yclid|_hsenc|_hsmi|vero_id|twclid|ttclid|wbraid|gbraid|ref_src)$/i;
const AD_PATH = /\/(pagead|adserver|prebid|adsbygoogle)(\/|\.|$)/i;
const NEUTER = { script: 'data:text/javascript,', stylesheet: 'data:text/css,', image: 'data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7' };
// Hides leftover ad boxes. Deliberately skips bait class names like .adsbox, because "ad blocker detected" scripts test those.
const COSMETIC = 'ins.adsbygoogle,iframe[src*="doubleclick.net"],iframe[src*="googlesyndication"],[id^="google_ads_iframe"],[id^="div-gpt-ad"],[data-ad-slot],.taboola,.OUTBRAIN,[id^="taboola-"],' +
  '#masthead-ad,ytd-ad-slot-renderer,ytd-in-feed-ad-layout-renderer,ytd-banner-promo-renderer,ytd-statement-banner-renderer,ytd-promoted-sparkles-web-renderer,ytd-display-ad-renderer,#player-ads,.ytp-ad-overlay-container,ytd-enforcement-message-view-model{display:none!important}';
const siteOf = (h) => h.split('.').slice(-2).join('.');
const BLOCK = new Set(('doubleclick.net googlesyndication.com googleadservices.com google-analytics.com googletagmanager.com googletagservices.com adservice.google.com ' +
  'connect.facebook.net scorecardresearch.com quantserve.com taboola.com outbrain.com criteo.com criteo.net adnxs.com rubiconproject.com pubmatic.com openx.net ' +
  'amazon-adsystem.com moatads.com hotjar.com mixpanel.com fullstory.com adsrvr.org casalemedia.com 2mdn.net advertising.com yieldmo.com smartadserver.com ' +
  'bidswitch.net demdex.net krxd.net bluekai.com chartbeat.com mookie1.com adform.net teads.tv media.net sharethrough.com indexww.com 33across.com tapad.com liadm.com permutive.com').split(' '));
const isBlocked = (host) => { for (let h = host; h.includes('.'); h = h.slice(h.indexOf('.') + 1)) if (BLOCK.has(h)) return true; return false; };
const lfile = () => path.join(app.getPath('userData'), 'blocklist.json');
const loadList = () => { try { JSON.parse(fs.readFileSync(lfile(), 'utf8')).forEach((d) => BLOCK.add(d)); } catch { /* none yet */ } };
// keeps only simple "||domain^" rules from EasyList-style files; skips anything with paths, wildcards or extra options
const parseRules = (txt) => { const out = []; for (const line of txt.split('\n')) { const m = line.trim().match(/^\|\|([a-z0-9.-]+\.[a-z]{2,})\^(\$third-party)?$/i); if (m) out.push(m[1].toLowerCase()); } return out; };
const firstParty = (d, host) => { try { const r = new URL(d.referrer).hostname; return r === host || r.endsWith('.' + host) || host.endsWith('.' + r); } catch { return false; } };
function uniquePath(dir, name) { const ext = path.extname(name), base = path.basename(name, ext); let p = path.join(dir, name), i = 1; while (fs.existsSync(p)) p = path.join(dir, `${base} (${i++})${ext}`); return p; }
ipcMain.on('reveal', (_e, p) => { if (typeof p === 'string' && path.resolve(p).startsWith(app.getPath('downloads'))) shell.showItemInFolder(p); });
const hardened = new Set();
function harden(ses, key) {
  if (hardened.has(key)) return; hardened.add(key);
  ses.webRequest.onBeforeRequest({ urls: ['http://*/*', 'https://*/*'] }, (d, cb) => {
    let u; try { u = new URL(d.url); } catch { return cb({}); }
    if (P.strip && (d.resourceType === 'mainFrame' || d.resourceType === 'subFrame') && d.method === 'GET') {
      let ch = false; for (const k of [...u.searchParams.keys()]) if (TRACK.test(k)) { u.searchParams.delete(k); ch = true; }
      if (ch) { S.stripped++; return cb({ redirectURL: u.toString() }); }
    }
    if (P.block && d.resourceType !== 'mainFrame' && !firstParty(d, u.hostname) && (isBlocked(u.hostname) || AD_PATH.test(u.pathname))) {
      S.blocked++; const r = NEUTER[d.resourceType]; return cb(r ? { redirectURL: r } : { cancel: true });   // scripts/images get an empty stand-in so the page doesn't see a failed load
    }
    if (P.https && u.protocol === 'http:' && !/^(localhost|127\.|\[::1\]|10\.|192\.168\.)/.test(u.hostname)) { u.protocol = 'https:'; return cb({ redirectURL: u.toString() }); }
    cb({});
  });
  ses.setPreloads([path.join(__dirname, 'stealth-preload.js')]);
  ses.webRequest.onBeforeSendHeaders({ urls: ['http://*/*', 'https://*/*'] }, (d, cb) => { d.requestHeaders['Sec-GPC'] = '1'; d.requestHeaders['DNT'] = '1'; cb({ requestHeaders: d.requestHeaders }); });
  ses.on('will-download', (_e, item) => {   // saves into ~/Downloads, never overwrites
    const p = uniquePath(app.getPath('downloads'), path.basename(item.getFilename())); item.setSavePath(p); const id = String(Date.now()) + Math.random();
    const info = (state) => ({ id, name: path.basename(p), path: p, state, got: item.getReceivedBytes(), total: item.getTotalBytes() });
    send('dl', info('progressing')); item.on('updated', (_ev, s) => send('dl', info(s === 'interrupted' ? 'interrupted' : 'progressing'))); item.once('done', (_ev, s) => send('dl', info(s)));
  });
  const ok = (p) => p === 'fullscreen' || p === 'clipboard-sanitized-write';   // camera, mic, location, notifications: always denied
  ses.setPermissionRequestHandler((_w, p, cb) => cb(ok(p)));
  ses.setPermissionCheckHandler((_w, p) => ok(p));
}
app.on('web-contents-created', (_e, wc) => {
  wc.on('will-attach-webview', (e, prefs, params) => {
    const part = params.partition || '';
    if (!/^(persist:main|private-\d+)$/.test(part) || !/^(https?:|about:blank)/.test(params.src || 'about:blank')) return e.preventDefault();
    delete prefs.preload; delete prefs.preloadURL;
    prefs.nodeIntegration = false; prefs.contextIsolation = true; prefs.sandbox = true; prefs.webSecurity = true;
    harden(session.fromPartition(part), part);
  });
  if (wc.getType() === 'webview') {
    wc.on('dom-ready', () => { if (P.cosmetic) wc.insertCSS(COSMETIC).catch(() => {}); });
    wc.setWindowOpenHandler(({ url, disposition }) => {   // pop-ups and pop-unders: same-site links open as tabs, other sites ask first
      let t; try { t = new URL(url); } catch { S.popups++; return { action: 'deny' }; }
      if (!/^https?:$/.test(t.protocol)) { S.popups++; return { action: 'deny' }; }
      let cur = ''; try { cur = new URL(wc.getURL()).hostname; } catch { /* ignore */ }
      if (!P.popups || disposition === 'background-tab' || siteOf(t.hostname) === siteOf(cur)) send('open-url', url);
      else { S.popups++; if (!isBlocked(t.hostname)) send('popup', url); }
      return { action: 'deny' };
    });
    wc.setWebRTCIPHandlingPolicy('default_public_interface_only');
  }
});

// ---------- encrypted vault (macOS Keychain via safeStorage) ----------
const vfile = (k) => path.join(app.getPath('userData'), 'vault', String(k).replace(/[^\w-]/g, '') + '.dat');
const enc = () => safeStorage.isEncryptionAvailable();
const SECRET = (k) => /^(aikey|bridgekeys)$/.test(String(k).replace(/[^\w-]/g, ''));
ipcMain.handle('vault:get', (_e, k) => { if (SECRET(k)) return null; try { const f = vfile(k); if (!fs.existsSync(f)) return null; const b = fs.readFileSync(f); return JSON.parse(enc() ? safeStorage.decryptString(b) : b.toString('utf8')); } catch { return null; } });
ipcMain.handle('vault:set', (_e, k, v) => { if (SECRET(k)) return false; const f = vfile(k); fs.mkdirSync(path.dirname(f), { recursive: true }); const s = JSON.stringify(v); fs.writeFileSync(f, enc() ? safeStorage.encryptString(s) : Buffer.from(s)); return enc(); });
const STEALTH_SRC = require('./stealth-main.js').toString();
ipcMain.on('stealth:cfg', (e) => {
  if (e.sender.getType() !== 'webview') { e.returnValue = null; return; }
  if (!P.stealth && !P.ytads && !P.block) { e.returnValue = null; return; }
  const ev = '__' + require('crypto').randomBytes(6).toString('hex');
  e.returnValue = { ev, code: '(' + STEALTH_SRC + ')(' + JSON.stringify({ fp: P.stealth, yt: P.ytads, stub: P.block, seed: SEED, ev }) + ')' };
});
ipcMain.on('stealth:fp', (e) => { if (e.sender.getType() === 'webview') S.fp++; });
const SEED = require('crypto').randomBytes(4).readUInt32LE(0);   // new every launch
let camo = 0; const CAMO = [1, 0.7, 0.4];
ipcMain.handle('camo', () => { camo = (camo + 1) % CAMO.length; win.setOpacity(CAMO[camo]); return CAMO[camo]; });
ipcMain.handle('privacy:get', () => ({ ...P, ...S, encrypted: enc(), listSize: BLOCK.size }));
ipcMain.handle('privacy:updateList', async () => {   // NOT local: downloads public filter lists from easylist.to
  const found = new Set();
  for (const u of ['https://easylist.to/easylist/easylist.txt', 'https://easylist.to/easylist/easyprivacy.txt']) {
    const r = await fetch(u, { signal: AbortSignal.timeout(30000) }); if (!r.ok) throw new Error('HTTP ' + r.status);
    parseRules(await r.text()).forEach((d) => found.add(d));
  }
  fs.writeFileSync(lfile(), JSON.stringify([...found])); found.forEach((d) => BLOCK.add(d)); return BLOCK.size;
});
ipcMain.handle('suggest', async (_e, q) => {   // NOT local, and OFF unless you turn it on: sends what you type to DuckDuckGo
  if (!P.suggest || typeof q !== 'string' || !q || q.length > 100) return [];
  try {
    const r = await fetch('https://duckduckgo.com/ac/?type=list&q=' + encodeURIComponent(q), { signal: AbortSignal.timeout(2500) }); const j = await r.json();
    return (Array.isArray(j) && Array.isArray(j[1]) ? j[1] : Array.isArray(j) ? j.map((x) => x.phrase) : []).filter(Boolean).slice(0, 5);
  } catch { return []; }
});
ipcMain.handle('privacy:set', (_e, k, v) => { if (typeof P[k] === 'boolean') { P[k] = !!v; saveSettings(); if (k === 'bridgeApi') (P.bridgeApi ? startApi() : stopApi()); } return { ...P }; });
ipcMain.handle('privacy:clear', async () => { const s = session.fromPartition('persist:main'); await s.clearStorageData(); await s.clearCache(); return true; });


// ---------- Copilot (NOT local: sends your commands to Anthropic's API using your own key) ----------
const { callModel } = require('./ai-core.js');
const getKey = () => { try { const b = fs.readFileSync(vfile('aikey')); return enc() ? safeStorage.decryptString(b) : b.toString('utf8'); } catch { return null; } };
ipcMain.handle('ai:hasKey', () => !!getKey());
ipcMain.handle('ai:setKey', (_e, k) => { if (typeof k !== 'string' || !/^sk-ant-[\w-]{20,}$/.test(k.trim())) return false; const f = vfile('aikey'); fs.mkdirSync(path.dirname(f), { recursive: true }); fs.writeFileSync(f, enc() ? safeStorage.encryptString(k.trim()) : Buffer.from(k.trim())); return true; });
ipcMain.handle('ai:clearKey', () => { try { fs.unlinkSync(vfile('aikey')); } catch { /* none */ } return true; });
ipcMain.handle('ai:ask', async (_e, messages) => {
  const key = getKey(); if (!key) return { error: 'nokey' };
  if (!Array.isArray(messages) || messages.length > 60 || JSON.stringify(messages).length > 200000 || !messages.every((m) => m && (m.role === 'user' || m.role === 'assistant'))) return { error: 'Conversation too long. Start a new one.' };
  try { return await callModel(key, null, messages); } catch (e) { return { error: String(e.message || e).replace(key, '***') }; }
});

// ---------- mods: AI-written interface changes, saved as small files, never edits Northstar's source ----------
const SAFE = process.argv.includes('--safe');
const mdir = () => path.join(app.getPath('userData'), 'mods'), marker = () => path.join(app.getPath('userData'), 'mods.loading');
const modFile = (id) => path.join(mdir(), id + '.json'), okId = (id) => typeof id === 'string' && /^m\d+$/.test(id);
const listMods = () => { try { return fs.readdirSync(mdir()).filter((f) => f.endsWith('.json')).map((f) => { try { return JSON.parse(fs.readFileSync(path.join(mdir(), f), 'utf8')); } catch { return null; } }).filter(Boolean); } catch { return []; } };
const cssKeys = {};
async function applyMod(m) {
  try { if (m.css) cssKeys[m.id] = await win.webContents.insertCSS(m.css); } catch { /* bad css */ }
  try { if (m.js) await win.webContents.executeJavaScript('(function(){try{\n' + m.js + '\n}catch(e){console.error("mod ' + m.id + '",e)}})()'); } catch { /* bad js */ }
}
function loadMods() {
  if (SAFE) { send('note', 'Safe mode: mods are off for this launch.'); return; }
  if (fs.existsSync(marker())) { fs.unlinkSync(marker()); send('note', 'Mods were skipped this launch because the last start did not finish cleanly. Open Copilot > Mods.'); return; }
  const on = listMods().filter((m) => m.on); if (!on.length) return;
  fs.writeFileSync(marker(), '1'); on.forEach(applyMod); setTimeout(() => { try { fs.unlinkSync(marker()); } catch { /* gone */ } }, 6000);
}
ipcMain.handle('mods:list', () => listMods().map(({ id, name, description, on, css, js }) => ({ id, name, description, on, css, js })));
ipcMain.handle('mods:save', async (_e, m) => {
  if (!m || typeof m.name !== 'string' || !m.name || m.name.length > 60 || (m.description || '').length > 300 || (m.css || '').length > 20000 || (m.js || '').length > 20000 || (!m.css && !m.js)) return null;
  const id = 'm' + Date.now(), rec = { id, name: m.name, description: String(m.description || ''), css: String(m.css || ''), js: String(m.js || ''), on: true };
  fs.mkdirSync(mdir(), { recursive: true }); fs.writeFileSync(modFile(id), JSON.stringify(rec)); await applyMod(rec); return id;
});
ipcMain.handle('mods:toggle', async (_e, id, on) => { if (!okId(id)) return false; try { const m = JSON.parse(fs.readFileSync(modFile(id), 'utf8')); m.on = !!on; fs.writeFileSync(modFile(id), JSON.stringify(m)); if (!on && cssKeys[id]) { await win.webContents.removeInsertedCSS(cssKeys[id]); delete cssKeys[id]; } else if (on) await applyMod(m); return true; } catch { return false; } });
ipcMain.handle('mods:remove', async (_e, id) => { if (!okId(id)) return false; try { if (cssKeys[id]) { await win.webContents.removeInsertedCSS(cssKeys[id]); delete cssKeys[id]; } fs.unlinkSync(modFile(id)); return true; } catch { return false; } });
const relaunch = (args) => { app.relaunch({ args: [...process.argv.slice(1).filter((a) => a !== '--safe'), ...args] }); app.exit(0); };
ipcMain.handle('restart', () => relaunch([]));
ipcMain.handle('opacity', (_e, v) => { const o = Math.max(0.3, Math.min(1, Number(v) || 1)); win.setOpacity(o); return o; });

// ---------- bridges ----------
// (1) Adom Bridge on this Mac, via its documented loopback API.  (2) Your own HTTP services (token stored encrypted, main-process only).
// (3) A local API so Codex or other tools on this Mac can drive Northstar (off by default, token required).
const os = require('os'), http = require('http'), ncrypto = require('crypto');
const adomBase = () => { let port = 47200; try { const p = parseInt(fs.readFileSync(path.join(os.homedir(), '.adom', 'direct-api-port'), 'utf8'), 10); if (p > 0 && p < 65536) port = p; } catch { /* default */ } return 'http://127.0.0.1:' + port; };
ipcMain.handle('bridge:adom', async (_e, command, args, appName) => {
  if (typeof command !== 'string' || !/^[a-z0-9_]{1,60}$/.test(command)) return 'error: bad command name';
  const a = args && typeof args === 'object' ? args : {}; if (JSON.stringify(a).length > 8000) return 'error: arguments too large';
  const ap = typeof appName === 'string' && /^[a-z0-9_-]{1,30}$/.test(appName) ? appName : 'desktop';
  try {
    const r = command === 'commands' ? await fetch(adomBase() + '/commands', { signal: AbortSignal.timeout(15000) })
      : await fetch(adomBase() + '/command', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ app: ap, command, args: a }), signal: AbortSignal.timeout(60000) });
    return (await r.text()).slice(0, 20000);
  } catch (e) { return 'error: Adom Bridge is not reachable on this Mac (' + e.message + '). Is it running in the menu bar?'; }
});
const bfile = () => vfile('bridgekeys');
const loadBridges = () => { try { const b = fs.readFileSync(bfile()); return JSON.parse(enc() ? safeStorage.decryptString(b) : b.toString('utf8')); } catch { return []; } };
const saveBridges = (l) => { fs.mkdirSync(path.dirname(bfile()), { recursive: true }); const t = JSON.stringify(l); fs.writeFileSync(bfile(), enc() ? safeStorage.encryptString(t) : Buffer.from(t)); };
ipcMain.handle('bridges:list', () => loadBridges().map((b) => ({ id: b.id, name: b.name, baseUrl: b.baseUrl, hasToken: !!b.token })));
ipcMain.handle('bridges:add', (_e, name, baseUrl, token) => {
  let u; try { u = new URL(String(baseUrl)); } catch { return 'error: not a valid address'; }
  const local = u.hostname === '127.0.0.1' || u.hostname === 'localhost';
  if (!(u.protocol === 'https:' || (u.protocol === 'http:' && local)) || u.username || u.password) return 'error: use https:// (http:// only for this Mac), no username in the address';
  const l = loadBridges(); if (l.length >= 10 || !name || String(name).length > 40) return 'error: too many bridges or bad name';
  l.push({ id: 'b' + Date.now(), name: String(name), baseUrl: u.origin + u.pathname.replace(/\/+$/, ''), token: token ? String(token).slice(0, 500) : '' }); saveBridges(l); return 'ok';
});
ipcMain.handle('bridges:remove', (_e, id) => { saveBridges(loadBridges().filter((b) => b.id !== id)); return true; });
ipcMain.handle('bridges:http', async (_e, id, method, p, body) => {
  const b = loadBridges().find((x) => x.id === id); if (!b) return 'error: no such bridge';
  if (!['GET', 'POST', 'PUT', 'PATCH', 'DELETE'].includes(method)) return 'error: bad method';
  if (typeof p !== 'string' || !/^\/[\w\-./~%:@!$&'()*+,;=?]*$/.test(p) || p.startsWith('//') || p.includes('..')) return 'error: bad path';
  if (body != null && (typeof body !== 'string' || body.length > 8000)) return 'error: body too large';
  const url = b.baseUrl + p; try { if (new URL(url).origin !== new URL(b.baseUrl).origin) return 'error: path left the bridge address'; } catch { return 'error: bad address'; }
  try {
    const h = { accept: 'application/json, text/plain' }; if (b.token) h.authorization = 'Bearer ' + b.token; if (body) h['content-type'] = 'application/json';
    const r = await fetch(url, { method, headers: h, body: body || undefined, redirect: 'manual', signal: AbortSignal.timeout(15000) });
    return r.status + '\n' + (await r.text()).slice(0, 20000);
  } catch (e) { return 'error: ' + String(e.message || e).replace(b.token || '\u0000', '***'); }
});
// Local API for Codex and other tools on this Mac: 127.0.0.1 only, random port and token written to ~/.northstar/api.json (owner-read only).
const INBOUND = ['open_tab', 'navigate', 'list_tabs', 'switch_tab', 'close_tab', 'list_rail', 'add_rail_site', 'set_theme', 'get_status', 'browser_command', 'set_window_opacity'];
let apiSrv = null; const pending = new Map(); const apiFile = () => path.join(os.homedir(), '.northstar', 'api.json');
function startApi() {
  if (apiSrv) return; const token = ncrypto.randomBytes(24).toString('hex');
  apiSrv = http.createServer((req, res) => {
    const reply = (c, o) => { res.writeHead(c, { 'content-type': 'application/json' }); res.end(JSON.stringify(o)); };
    if (!/^127\.0\.0\.1:\d+$/.test(req.headers.host || '') || req.headers.origin) return reply(403, { error: 'forbidden' });   // blocks web pages and DNS tricks
    if (req.headers.authorization !== 'Bearer ' + token) return reply(401, { error: 'unauthorized' });
    if (req.method === 'GET' && req.url === '/tools') return reply(200, { tools: INBOUND });
    if (req.method !== 'POST' || req.url !== '/tool') return reply(404, { error: 'not found' });
    let b = ''; req.on('data', (d) => { b += d; if (b.length > 20000) req.destroy(); });
    req.on('end', () => {
      let j; try { j = JSON.parse(b); } catch { return reply(400, { error: 'bad json' }); }
      if (!j || !INBOUND.includes(j.name)) return reply(400, { error: 'tool not allowed' });
      const id = ncrypto.randomBytes(6).toString('hex'), t = setTimeout(() => { pending.delete(id); reply(504, { error: 'timeout' }); }, 15000);
      pending.set(id, (r) => { clearTimeout(t); reply(200, { result: r }); }); send('api', { id, name: j.name, input: j.input && typeof j.input === 'object' ? j.input : {} });
    });
  });
  apiSrv.listen(0, '127.0.0.1', () => { try { fs.mkdirSync(path.dirname(apiFile()), { recursive: true, mode: 0o700 }); fs.writeFileSync(apiFile(), JSON.stringify({ port: apiSrv.address().port, token })); fs.chmodSync(apiFile(), 0o600); } catch { /* ignore */ } });
}
function stopApi() { if (apiSrv) { apiSrv.close(); apiSrv = null; } try { fs.unlinkSync(apiFile()); } catch { /* none */ } }
ipcMain.on('api:reply', (e, id, r) => { if (!win || e.sender !== win.webContents) return; const f = pending.get(id); if (f) { pending.delete(id); f(String(r).slice(0, 20000)); } });
app.on('will-quit', stopApi);

// ---------- window + system tools ----------
function toggleTop() { const v = !win.isAlwaysOnTop(); win.setAlwaysOnTop(v); send('top-state', v); return v; }
function tool(n) {
  if (n === 'activity') execFile('open', ['-a', 'Activity Monitor']);
  if (n === 'settings') execFile('open', ['-a', 'System Settings'], (e) => { if (e) execFile('open', ['-a', 'System Preferences']); });
  if (n === 'forcequit') execFile('osascript', ['-e', 'tell application "System Events" to key code 53 using {command down, option down}']);
}
ipcMain.handle('top', toggleTop);
ipcMain.on('tool', (_e, n) => tool(n));
function menu() {
  const it = (label, accelerator, click) => ({ label, accelerator, click });
  const tabs = [1, 2, 3, 4, 5, 6, 7, 8, 9].map((n) => it('Tab ' + n, 'CmdOrCtrl+' + n, () => send('tab-number', n - 1)));
  Menu.setApplicationMenu(Menu.buildFromTemplate([
    { role: 'appMenu' },
    { label: 'File', submenu: [it('New Tab', 'CmdOrCtrl+T', () => send('new-tab')), it('New Private Tab', 'CmdOrCtrl+Shift+N', () => send('private-tab')), it('Close Tab', 'CmdOrCtrl+W', () => send('close-tab'))] },
    { role: 'editMenu' },
    { label: 'View', submenu: [it('Reload', 'CmdOrCtrl+R', () => send('reload')), it('Find in Page', 'CmdOrCtrl+F', () => send('find')),
      it('Bookmark This Page', 'CmdOrCtrl+D', () => send('bookmark')), it('Bookmarks Bar', 'CmdOrCtrl+Shift+B', () => send('bmbar')), it('Downloads', 'CmdOrCtrl+Shift+J', () => send('downloads')),
      it('Zoom In', 'CmdOrCtrl+Plus', () => send('zoom', 1)), it('Zoom Out', 'CmdOrCtrl+-', () => send('zoom', -1)), it('Actual Size', 'CmdOrCtrl+0', () => send('zoom', 0)), { type: 'separator' }, it('Focus Address Bar', 'CmdOrCtrl+L', () => send('focus-address')),
      it('Split View', 'CmdOrCtrl+Shift+D', () => send('split')), it('Vertical Tabs', 'CmdOrCtrl+Alt+T', () => send('vtabs')), { type: 'separator' },
      it('Next Tab', 'CmdOrCtrl+Shift+]', () => send('step', 1)), it('Previous Tab', 'CmdOrCtrl+Shift+[', () => send('step', -1)), { type: 'separator' }, ...tabs, { type: 'separator' }, { role: 'togglefullscreen' }] },
    { label: 'Rail', submenu: [1, 2, 3, 4, 5, 6, 7, 8, 9].map((n) => it('Open Rail Slot ' + n, 'CmdOrCtrl+Alt+' + n, () => send('rail-slot', n - 1))) },
    { label: 'Music', submenu: [it('Music Hub', 'CmdOrCtrl+Alt+M', () => send('music-view')), it('Play / Pause', 'CmdOrCtrl+Alt+P', () => send('music-toggle')),
      it('Next Track', 'CmdOrCtrl+Alt+Right', () => send('music-next')), it('Previous Track', 'CmdOrCtrl+Alt+Left', () => send('music-prev'))] },
    { label: 'Window', submenu: [it('Keep on Top', 'CmdOrCtrl+Shift+P', toggleTop), ...[1, 0.8, 0.6, 0.4].map((o) => it('See-through ' + o * 100 + '%', null, () => win.setOpacity(o))), { type: 'separator' }, { role: 'minimize' }, { role: 'zoom' }] },
    { label: 'Copilot', submenu: [it('Open Copilot', 'CmdOrCtrl+K', () => send('copilot')), { type: 'separator' },
      it('Safe Mode (mods off) and Restart', null, () => relaunch(['--safe'])),
      it('Turn Off All Mods and Restart', null, () => { listMods().forEach((m) => { m.on = false; try { fs.writeFileSync(modFile(m.id), JSON.stringify(m)); } catch { /* ignore */ } }); relaunch([]); })] },
    { label: 'Tools', submenu: [it('Force Quit', null, () => tool('forcequit')), it('Activity Monitor', null, () => tool('activity')), it('System Settings', null, () => tool('settings'))] },
  ]));
}
app.whenReady().then(() => {
  loadSettings(); loadList(); menu(); if (P.bridgeApi) startApi();
  win = new BrowserWindow({ width: 1320, height: 840, minWidth: 760, minHeight: 480, title: 'Northstar', backgroundColor: '#0a0c11',
    webPreferences: { preload: path.join(__dirname, 'preload.js'), webviewTag: true, contextIsolation: true, sandbox: true } });
  win.webContents.on('will-navigate', (e) => e.preventDefault());
  win.webContents.setWindowOpenHandler(() => ({ action: 'deny' }));
  win.webContents.once('did-finish-load', loadMods);
  win.loadFile('index.html');
});
app.on('window-all-closed', () => app.quit());
