// Runs INSIDE web pages, before the page's own scripts (injected by stealth-preload.js).
// Goal: make fingerprinting less useful and make ad-blocking harder for a site to notice.
// Honest limit: nothing here is guaranteed "undetectable". Sites update their detection; treat this as a moving target.
module.exports = function stealthMain(C) {
  'use strict';
  const W = window, call = Reflect.apply;
  const nativeTS = Function.prototype.toString, fakeStr = new WeakMap();
  const ts = new Proxy(nativeTS, { apply: (t, th, a) => (fakeStr.has(th) ? fakeStr.get(th) : call(t, th, a)) });
  Object.defineProperty(Function.prototype, 'toString', { value: ts, writable: true, configurable: true });
  fakeStr.set(ts, call(nativeTS, nativeTS, []));   // patched functions still print as "[native code]"
  const seen = {}, ping = (k) => { if (seen[k]) return; seen[k] = 1; try { W.dispatchEvent(new Event(C.ev)); } catch { /* ignore */ } };
  const hook = (obj, name, impl) => {
    try {
      const d = Object.getOwnPropertyDescriptor(obj, name); if (!d || typeof d.value !== 'function') return;
      const p = new Proxy(d.value, { apply: (t, th, a) => impl(t, th, a) });
      fakeStr.set(p, call(nativeTS, d.value, [])); Object.defineProperty(obj, name, { value: p, writable: true, configurable: true, enumerable: d.enumerable });
    } catch { /* ignore */ }
  };
  const getter = (obj, name, val) => {
    try {
      const d = Object.getOwnPropertyDescriptor(obj, name); if (!d || !d.get) return;
      const g = new Proxy(d.get, { apply: () => val }); fakeStr.set(g, call(nativeTS, d.get, []));
      Object.defineProperty(obj, name, { get: g, set: d.set, enumerable: d.enumerable, configurable: true });
    } catch { /* ignore */ }
  };
  // Noise is deterministic per site per app launch (same input -> same output), so a fingerprinter that reads twice
  // sees consistent values, but the value differs from other sites and from your real hardware.
  const site = (() => { let h = (2166136261 ^ C.seed) >>> 0; const s = location.hostname; for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); } return h >>> 0; })();
  const bump = (d) => { for (let i = 0; i < d.length; i += 4) if (((Math.imul(i >>> 2, 2654435761) ^ site) >>> 0) % 173 === 0) d[i] ^= 1; };

  if (C.fp) {
    const CP = W.HTMLCanvasElement.prototype, X = W.CanvasRenderingContext2D.prototype, rawGet = X.getImageData;
    const copy = (src) => {
      try {
        const w = src.width, h = src.height; if (w * h < 256 || w * h > 4e6) return null;
        const c = document.createElement('canvas'); c.width = w; c.height = h; const x = c.getContext('2d'); x.drawImage(src, 0, 0);
        const id = call(rawGet, x, [0, 0, w, h]); bump(id.data); x.putImageData(id, 0, 0); ping('canvas'); return c;
      } catch { return null; }
    };
    hook(CP, 'toDataURL', (t, th, a) => call(t, copy(th) || th, a));
    hook(CP, 'toBlob', (t, th, a) => call(t, copy(th) || th, a));
    hook(X, 'getImageData', (t, th, a) => { const r = call(t, th, a); try { if (r.width * r.height >= 256) { bump(r.data); ping('canvas'); } } catch { /* ignore */ } return r; });
    for (const G of [W.WebGLRenderingContext, W.WebGL2RenderingContext]) if (G) hook(G.prototype, 'getParameter', (t, th, a) => {
      if (a[0] === 37445) { ping('webgl'); return 'Google Inc. (Apple)'; }
      if (a[0] === 37446) { ping('webgl'); return 'ANGLE (Apple, ANGLE Metal Renderer: Apple M1, Unspecified Version)'; }
      return call(t, th, a);
    });
    if (W.AudioBuffer) { const done = new WeakSet(); hook(W.AudioBuffer.prototype, 'getChannelData', (t, th, a) => {
      const r = call(t, th, a); if (!done.has(r)) { done.add(r); for (let i = 0; i < r.length; i += 97) r[i] += ((Math.imul(i, 2654435761) ^ site) % 7 - 3) * 1e-7; ping('audio'); } return r; }); }
    getter(W.Navigator.prototype, 'hardwareConcurrency', 8); getter(W.Navigator.prototype, 'deviceMemory', 8);
    hook(W.Navigator.prototype, 'getBattery', () => Promise.resolve({ charging: true, chargingTime: 0, dischargingTime: Infinity, level: 1, addEventListener() {}, removeEventListener() {} }));
  }

  // Many "ad blocker detected" scripts just check that the ad library loaded. Give them a harmless stand-in.
  if (C.stub && !W.adsbygoogle) { try { Object.defineProperty(W, 'adsbygoogle', { value: { loaded: true, push() {} }, writable: true, configurable: true }); } catch { /* ignore */ } }

  // YouTube serves ads from its own domain, so domain blocking can't touch them. This skips them from inside the page.
  // Most fragile part of Northstar: YouTube changes its page often and actively fights this. Expect it to need repair.
  if (C.yt && /(^|\.)youtube\.com$/.test(location.hostname)) {
    let mutedByUs = false;
    setInterval(() => {
      try {
        const p = document.querySelector('.html5-video-player.ad-showing, .html5-video-player.ad-interrupting'), v = document.querySelector('video.html5-main-video, video');
        if (p && v) { if (!v.muted) { v.muted = true; mutedByUs = true; } if (isFinite(v.duration) && v.duration > 0) v.currentTime = v.duration; const b = p.querySelector('[class*="skip-button"], .ytp-ad-skip-button-modern'); if (b) (b.closest('button') || b).click(); }
        else if (mutedByUs && v) { v.muted = false; mutedByUs = false; }
        const x = document.querySelector('.ytp-ad-overlay-close-button'); if (x) x.click();
        const e = document.querySelector('ytd-enforcement-message-view-model'); if (e) { const b = document.querySelector('#dismiss-button button, [aria-label="Close"]'); if (b) b.click(); e.remove(); if (v && v.paused) v.play().catch(() => {}); }
      } catch { /* ignore */ }
    }, 300);
  }
};
