(() => {
const $ = (s) => document.querySelector(s);
const NS = (window.NS = { cmds: {} });
const LS = (k, d) => { try { return JSON.parse(localStorage.getItem(k)) ?? d; } catch { return d; } };
let sites = LS('sites', null) || [{ name: 'YouTube Music', url: 'https://music.youtube.com' }, { name: 'YouTube', url: 'https://www.youtube.com' }, { name: 'SoundCloud', url: 'https://soundcloud.com' }, { name: 'DuckDuckGo', url: 'https://duckduckgo.com' }];
let favs = LS('favs', {});
const saveSites = () => localStorage.setItem('sites', JSON.stringify(sites));
const BANGS = { '!yt': (q) => 'https://www.youtube.com/results?search_query=' + q, '!ytm': (q) => 'https://music.youtube.com/search?q=' + q, '!sc': (q) => 'https://soundcloud.com/search?q=' + q,
  '!g': (q) => 'https://www.google.com/search?q=' + q, '!w': (q) => 'https://en.wikipedia.org/wiki/Special:Search?search=' + q, '!gh': (q) => 'https://github.com/search?q=' + q, '!ddg': (q) => 'https://duckduckgo.com/?q=' + q };
NS.norm = (s) => {
  s = s.trim(); const m = s.match(/^(!\w+)\s+(.+)/); if (m && BANGS[m[1]]) return BANGS[m[1]](encodeURIComponent(m[2]));
  if (/^https?:\/\//i.test(s)) return s; if (s.includes('.') && !s.includes(' ') && !s.startsWith('.')) return 'https://' + s;
  return (NS.engineUrl ? NS.engineUrl() : 'https://duckduckgo.com/?q=') + encodeURIComponent(s);
};
const ico = (el, name) => { el.innerHTML = ic(name); };
[['brand', 'star'], ['add', 'plus'], ['bMusic', 'music'], ['bShield', 'shield'], ['bCamo', 'eye'], ['bTheme', 'palette'], ['bTop', 'pin'], ['bFq', 'power'], ['bAm', 'pulse'], ['bSs', 'gear'], ['bk', 'back'], ['fw', 'fwd'], ['rl', 'reload']].forEach(([i, n]) => ico($('#' + i), n));

// ---- helpers shared with the music module ----
NS.mk = (url, part = 'persist:main') => {
  const w = document.createElement('webview'); w.setAttribute('partition', part); w.setAttribute('allowpopups', ''); w.setAttribute('webpreferences', 'autoplayPolicy=no-user-gesture-required');
  if (url) w.src = url; w.addEventListener('dom-ready', () => { w.__ready = true; });
  w.addEventListener('page-favicon-updated', (e) => {
    if (part !== 'persist:main') return;   // private tabs never write anything down
    try { const host = new URL(w.getURL()).hostname; if (e.favicons[0] && !favs[host] && !logoFor(w.getURL())) { favs[host] = e.favicons[0]; localStorage.setItem('favs', JSON.stringify(favs)); rail(); } } catch { /* ignore */ }
  });
  return w;
};
NS.ctx = (x, y, items) => {
  const c = $('#ctx'); c.innerHTML = '';
  items.forEach(([l, f]) => c.append(h('div', { onclick: () => { c.style.display = 'none'; f(); } }, l)));
  c.style.left = Math.min(x, innerWidth - 190) + 'px'; c.style.top = Math.min(y, innerHeight - 40 * items.length - 20) + 'px'; c.style.display = 'block';
};
document.addEventListener('click', () => { $('#ctx').style.display = 'none'; });
NS.ask = (title, fields) => new Promise((res) => {
  const d = $('#dlg'); d.innerHTML = ''; let done = false;
  const fin = (v) => { if (done) return; done = true; if (d.open) d.close(); res(v); };
  const ins = fields.map((f) => h('input', { placeholder: f }));
  d.onclose = () => fin(null);
  d.append(h('b', {}, title), ...ins, h('div', { class: 'row' }, h('button', { class: 'ghost', onclick: () => fin(null) }, 'Cancel'), h('button', { class: 'cta', onclick: () => fin(ins.map((i) => i.value.trim())) }, 'OK')));
  d.showModal(); if (ins[0]) ins[0].focus();
});

NS.siteIcon = (s) => siteIcon(s); NS.sites = () => sites;
// ---- tabs ----
let tabs = [], cur = null, seq = 0, panelSite = null; const panelViews = {};
NS.allViews = () => [...tabs.map((t) => t.wv), ...Object.values(panelViews), ...(NS.musicViews ? NS.musicViews() : [])];
function newTab(url, priv) {
  const t = { id: ++seq, title: priv ? 'Private tab' : 'New Tab', url: url || '', priv: !!priv };
  t.wv = NS.mk(url, priv ? 'private-' + t.id : 'persist:main');
  const nav = (e) => { if (e.isMainFrame === false) return; t.url = e.url; if (t === cur) setAddr(); if (NS.onVisit) NS.onVisit(t); };
  t.wv.addEventListener('page-title-updated', (e) => { t.title = e.title; draw(); });
  t.wv.addEventListener('page-favicon-updated', (e) => { t.icon = e.favicons[0]; draw(); });
  t.wv.addEventListener('did-navigate', nav); t.wv.addEventListener('did-navigate-in-page', nav);
  $('#views').append(t.wv); tabs.push(t); select(t); if (!url) $('#addr').focus(); return t;
}
function setAddr() { const u = cur ? cur.url : ''; $('#addr').value = u; $('#lockic').innerHTML = ic(cur && cur.priv ? 'mask' : 'lock'); $('#lockic').style.opacity = !u || u.startsWith('https:') || (cur && cur.priv) ? 1 : .3; }
function select(t) { cur = t; tabs.forEach((x) => x.wv.classList.toggle('hide', !((x === t || x === NS.partner) && x.url))); $('#home').classList.toggle('hide', !!(t.url || NS.partner)); setAddr(); draw(); }
function closeTab(t) { const i = tabs.indexOf(t); if (i < 0) return; if (NS.partner === t) NS.partner = null; t.wv.remove(); tabs.splice(i, 1); if (!tabs.length) newTab(); else if (cur === t) select(tabs[Math.min(i, tabs.length - 1)]); else draw(); }
function go(text) { const u = NS.norm(text); const t = cur || newTab(); t.url = u; t.wv.src = u; select(t); t.wv.focus(); }
function draw() {
  const el = $('#tabs'); el.innerHTML = '';
  tabs.forEach((t) => el.append(h('div', { class: 'tab' + (t === cur ? ' on' : '') + (t.priv ? ' priv' : '') + (t === NS.partner ? ' split' : ''), onclick: () => select(t), onauxclick: () => closeTab(t) },
    t.priv ? h('span', { class: 'ico', html: ic('mask'), style: 'flex:none' }) : t.icon ? h('img', { src: t.icon }) : '', h('span', {}, t.title), h('span', { class: 'x ico', html: ic('close'), style: 'flex:none', onclick: (e) => { e.stopPropagation(); closeTab(t); } }))));
  el.append(h('button', { class: 'ib ico', html: ic('plus'), title: 'New tab (⌘T)', onclick: () => newTab() }));
  if (NS.saveTabs) NS.saveTabs();
}

// ---- rail ----
function siteIcon(s) {
  const l = logoFor(s.url); if (l) return h('span', { class: 'logo', html: l });
  let host = ''; try { host = new URL(s.url).hostname; } catch { /* ignore */ }
  return favs[host] ? h('img', { class: 'logo', src: favs[host] }) : h('span', { class: 'logo letter' }, s.name.slice(0, 1).toUpperCase());
}
function rail() {
  const el = $('#sites'); el.innerHTML = '';
  sites.forEach((s, i) => el.append(h('button', { class: 'site' + (panelSite === i ? ' on' : ''), title: s.name + ' — opens in the side panel', onclick: () => togglePanel(i),
    oncontextmenu: (e) => { e.preventDefault(); NS.ctx(e.clientX, e.clientY, [['Open in new tab', () => newTab(s.url)], ['Remove from rail', () => { sites.splice(i, 1); saveSites(); closePanel(); }]]); } }, siteIcon(s), h('i', { class: 'slot' }, String(i + 1)))));
  if (NS.drawHome) NS.drawHome();
}
function closePanel() { $('#panel').classList.remove('show'); panelSite = null; rail(); }
function togglePanel(i) {
  const s = sites[i]; if (!s) return; if (panelSite === i) return closePanel();
  if (!panelViews[s.url]) { panelViews[s.url] = NS.mk(s.url); $('#panel').append(panelViews[s.url]); }
  Object.entries(panelViews).forEach(([u, w]) => w.classList.toggle('hide', u !== s.url));
  $('#panel').classList.add('show'); panelSite = i; rail();
}
$('#add').onclick = async () => { const r = await NS.ask('Add a site to the rail', ['Name', 'example.com']); if (r && r[1]) { sites.push({ name: r[0] || r[1], url: NS.norm(r[1]) }); saveSites(); rail(); } };

// ---- address bar, toolbar, window ----
const call = (f) => { try { f(); } catch { /* page not ready */ } };
$('#bk').onclick = () => call(() => cur.wv.goBack()); $('#fw').onclick = () => call(() => cur.wv.goForward()); $('#rl').onclick = () => call(() => cur.wv.reload());
$('#addr').addEventListener('keydown', (e) => { if (e.key === 'Enter') go($('#addr').value); });
$('#bTop').onclick = () => ns.top().then((v) => $('#bTop').classList.toggle('on', v));
$('#bFq').onclick = () => ns.tool('forcequit'); $('#bAm').onclick = () => ns.tool('activity'); $('#bSs').onclick = () => ns.tool('settings');
const themes = ['iwmd', 'aurora', 'ember', 'sage', 'mono']; document.body.dataset.theme = LS('theme', 'iwmd');
$('#bTheme').onclick = () => { const n = themes[(themes.indexOf(document.body.dataset.theme) + 1) % themes.length]; document.body.dataset.theme = n; localStorage.setItem('theme', JSON.stringify(n)); };
let drag = false;
$('#grip').onmousedown = () => { drag = true; document.body.classList.add('drag'); };
addEventListener('mouseup', () => { drag = false; document.body.classList.remove('drag'); });
addEventListener('mousemove', (e) => { if (drag) $('#panel').style.width = Math.max(260, Math.min(e.clientX - 60, innerWidth - 420)) + 'px'; });

// ---- privacy panel (everything it says is what the code does) ----
async function refreshPrivacy() {
  const p = await ns.privacy.get(); $('#pHttps').checked = p.https; $('#pBlock').checked = p.block; $('#pCosm').checked = p.cosmetic; $('#pYt').checked = p.ytads; $('#pFp').checked = p.stealth; $('#pStrip').checked = p.strip; $('#pPop').checked = p.popups;
  $('#stats').innerHTML = [['Ads/trackers', p.blocked], ['Pop-ups', p.popups], ['Links cleaned', p.stripped], ['Fingerprint reads fuzzed', p.fp]].map(([l, v]) => `<span class="st"><i>${l}</i><b>${v || 0}</b></span>`).join(''); $('#pCount').textContent = `(${p.blocked} blocked this session)`;
  $('#pEnc').textContent = p.encrypted ? 'Encrypted storage: ON (macOS Keychain).' : 'Encrypted storage: NOT available on this Mac — data is saved unencrypted.';
}
$('#bShield').onclick = (e) => { e.stopPropagation(); $('#privacy').classList.toggle('hide'); refreshPrivacy(); };
$('#privacy').onclick = (e) => e.stopPropagation(); document.addEventListener('click', () => $('#privacy').classList.add('hide'));
$('#pHttps').onchange = (e) => ns.privacy.set('https', e.target.checked); $('#pBlock').onchange = (e) => ns.privacy.set('block', e.target.checked);
[['pCosm', 'cosmetic'], ['pYt', 'ytads'], ['pFp', 'stealth'], ['pStrip', 'strip'], ['pPop', 'popups']].forEach(([i, k]) => { $('#' + i).onchange = (e) => ns.privacy.set(k, e.target.checked); });
$('#bCamo').onclick = () => ns.camo().then((o) => $('#bCamo').classList.toggle('on', o < 1));
$('#pPriv').onclick = () => { newTab('', true); $('#privacy').classList.add('hide'); };
$('#pClear').onclick = async () => { const r = await NS.ask('Clear browsing data? This signs you out of sites and music services. Type YES.', ['YES']); if (r && r[0].toUpperCase() === 'YES') { await ns.privacy.clear(); $('#privacy').classList.add('hide'); } };

// ---- commands from the menu ----
ns.on((name, arg) => {
  const i = tabs.indexOf(cur);
  if (name === 'new-tab') newTab(); else if (name === 'private-tab') newTab('', true); else if (name === 'close-tab') cur && closeTab(cur);
  else if (name === 'open-url') newTab(arg); else if (name === 'reload') call(() => cur.wv.reload());
  else if (name === 'focus-address') { $('#addr').focus(); $('#addr').select(); }
  else if (name === 'step' && tabs.length) select(tabs[(i + arg + tabs.length) % tabs.length]);
  else if (name === 'tab-number' && tabs[arg]) select(tabs[arg]);
  else if (name === 'top-state') $('#bTop').classList.toggle('on', arg);
  else if (NS.cmds[name]) NS.cmds[name](arg);
  else if (name.startsWith('music-') && NS.musicCmd) NS.musicCmd(name);
});
NS.close = closeTab; NS.addSite = (name, url) => { sites.push({ name, url: NS.norm(url) }); saveSites(); rail(); }; NS.removeSite = (i) => { sites.splice(i, 1); saveSites(); closePanel(); };
NS.setTheme = (n) => { if (themes.includes(n)) { document.body.dataset.theme = n; localStorage.setItem('theme', JSON.stringify(n)); } }; NS.themes = themes;
NS.tabs = () => tabs; NS.cur = () => cur; NS.select = select; NS.go = go; NS.newTab = newTab; NS.partner = null;
let restoring = true;
NS.saveTabs = () => { if (restoring) return; const v = tabs.filter((t) => !t.priv && t.url); localStorage.setItem('session', JSON.stringify({ urls: v.map((t) => t.url), cur: Math.max(0, v.indexOf(cur)) })); };
rail();
const ses = LS('session', null);
if (ses && ses.urls && ses.urls.length) { ses.urls.forEach((u) => newTab(u)); select(tabs[Math.min(ses.cur || 0, tabs.length - 1)]); } else newTab();
restoring = false; NS.saveTabs(); NS.cmds['rail-slot'] = (i) => togglePanel(i);
})();
