#!/bin/bash
# Starts Northstar. Downloads Electron's official Mac runtime once if it isn't there yet.
cd "$(dirname "$0")"
R="$HOME/ElectronRuntime/Electron.app"
if [ ! -d "$R" ]; then
  A=$(uname -m); [ "$A" = x86_64 ] && A=x64
  curl -L -o /tmp/electron.zip "https://github.com/electron/electron/releases/download/v33.2.1/electron-v33.2.1-darwin-$A.zip" && mkdir -p "$HOME/ElectronRuntime" && ditto -x -k /tmp/electron.zip "$HOME/ElectronRuntime"
fi
exec "$R/Contents/MacOS/Electron" "$PWD" "$@"
